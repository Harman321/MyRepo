# 多对ssh key pair的配置

ssh-keygen生成两个key pair分别用于链接公司gitlab和自己的github库

## 问题背景  

通常情况下，git仓库如github都是通过使用SSH协议与客户端连接，就是说使用ssh-keygen生成一个密钥对，将公钥id_rsa.pub放到仓库的项目里，每次连接时SSH客户端发送本地私钥（默认~/.ssh/id_rsa）到服务端验证。验证通过后，本地仓库就可以与服务器进行数据交换了。  但是在实际工作中，一般公司都会搭建私有的git仓库（gitlab.xxx.com），于是就会存在这样的情况，在github有你私人的账户，而公司的gitlab中有我的工作账号。  在同一台电脑上，我们不能指望通过ssh-keygen生成的一对密钥对，既能访问github又能访问公司私有的gitlab。    



## 解决办法 

 必须对每个账号分别生成独立的公钥密钥对。在链接到github时，使用账户1的公钥密钥对，链接到公司搭建的gitlab时，使用账户2的公钥密钥对。  



首先，进入~/.ssh目录下   

 `cd ~/.ssh`  

生成用于访问github的密钥对id_rsa，id_rsa.pub。  

  `ssh-keygen -t -rsa -C 'xxxx1@163.com'`  

再生成用于访问公司搭建的gitlab的密钥对id_rsa_xxx，id_rsa_xxx.pub。    

`ssh-keygen -t rsa -C 'xxxxx2@xxx.com' -f id_rsa_xxx`  



将生成id_rsa.pub添加到的github的账号Settings中， 将生成的id_rsa_xxx.pub添加到的gitlab的账号Settings中。  



然后在~/.ssh 目录下创建config文件，该文件用于配置私钥对应的服务器。

内容如下：

```
host gitlab.xxx.com 		##可以随意命名，链接时使用这个名字 
       hostName gitlab.xxx.com 		可以是域名形式
       user git 
       port 22 
       identityFile ~/.ssh/id_rsa_xxx 

 host server 
       hostName 10.20.21.121 		可以时IP形式
       user git 
       port 29418	//ssh的监听端口 
       identityFile ~/.ssh/id_rsa   

解释：
ssh xx@10.10.21.131
其中xx对应~/.ssh/config文件中的User
其中10.10.21.131对应~/.ssh/config文件中的HostName
其中xx@10.10.21.131对应~/.ssh/config文件中的Host

```

至此，大功告成。  当链接到gitlab.xxx.com上的仓库时，会使用id_ras_xxx验证远端的公钥是否匹配。而链接到github.com上的仓库时，则使用id_ras验证远端的公钥是否匹配。            













