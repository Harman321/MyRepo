# Capability- and Object-Based System Concepts



## Essential System Fundation

1. Information sharing and communication

一个系统最根本的功能应该是Information的动态共享以及exchange。而要实现Information sharing，可以通过addressing或者named objects。在Conventional System中，Sharing是比较困难的，因为addressing is a local

to a single process。如果addressing能够在两个进程之间进行transmite，那么实现resource 的sharing就会比较容易。

2. Protection and Safety

Conventional System中，一个user的所有objects是能够被这个user运行的所有进程访问的。如果用户能够限制它的一个Process只能够访问程序自身运行需要的objects，那么Protection和Safety就都能够提高。



3. Reliable construction and maintanance of complex systems(复杂系统的可靠构建和维护)

Convention System仅支持单一的操作特权模式。这种结构导致任何一个想要protection的模块都必须称为operating system kernel的一部分。如果任何一个模块能够运行在各自独立的受保护的domain中，那么系统就能够建立成为相互独立的用户独立扩展的模块的一个集合。







An Alternative Architecture structure：Capability-based addressing

Capability-based system支持object-based的方法来conputing





## Capabilities

Capability提供了：（1）单一的机制来address both primary and secondary memory。（2）单一的机制来address 软硬件资源（H/W resource）。

从概念上将，Capability就是一种（不可伪造的）令牌后者钥匙（token or key）,访问者只有拿到了这个Capability，并且符合Capability中定义的权限，才能够访问系统中的resource（objects）。一个Capability会包含两部分的内容：

（1）a unique object identifier: addresses or names a single object

​	这里的object表示系统中任何一个逻辑的或者物理的entry，例如：一段内存，一个数组，一个文件，一个消息端口等等。

（2）access rights to the unique object：defines opreation that can be performed on that object.例如：

访问权限能够限定 对一个内存段的 只读访问权限，同样也能够限定对 一个message port 的发送和接受权限。

 ![](pic\capability\capability_regions.png)

不可伪造：

Capability system会禁止直接编程修改capability list，capability lists只能通过kernel自身或者硬件来改变。用户可以执行kernel程序或者硬件来得到一个新的capability。例如：一个进程调用一个操作系统routuin创建一个新的文件，操作系统在这个进程的capability-list中保存了用于保护那个文件的capability



capability-based system同时也提供了若干capability operation

- Move capability  to different locations in a capability list(ctable-->utable)
- delete a capability(revok or reject)
- rstrict the rights in a capability
- pass a capability as a parameter to a procedure
- transmit a capability to another user in the system.(grant)



## Memory Addressing in Computer System



![](pic\capability\conventional.png)



特点：

- 系统支持分段的进程虚拟地址空间

虚拟地址空间是进程local的，虚拟地址到物理地址的转换也是通过进程local的proces-local segment translation

- 一个进程能够构建出任意的虚拟地址，并且能够尝试着对其read or write

对每一refernce，硬件负责保证：（1）响应的segment存在（2）offset是有效的（3）attempted opration是permited。除此之外，将会产生一个错误信号。

- Loading Segment Table Entries是一个特权操作，这个操作只能由operating system来执行

Process-Local Segment Table是在load a process的时候建立的，然后Process运行在一个静态的addressing enviroment

- 在两个进城之间share segment需要operatiing system分别处理两个进程的local segment table

  使他们能够address到共享的segment。

- 任何segment的dynamic sharing都需要opreating system干预



![](pic\capability\capabilty-based.png)

capability-based system也支持进程这个概念，进程代表了一个程序执行的环境。

每个process有一个capability-list，用于标明process能够access的segment。

capability addressing system包含一个capability register的集合。



- 系统支持分段的虚拟地址空间

  如果a capability for that segment已经被加载到capability的register，那么一段内存的寻址仅仅需要一条指令

- 在Conventional system加载一个segment discriptor需要特权操作，但是load a capability register不需要特权操作

- capability system提供了address space 的dynamic change。任何时候进程改变了它的任何一个capability register，都会引起address space的改变

- feature4

- a capability is not process-local。Capability是context independent。也就是说，segment addressed by a capability is independent of the process using the capability。一个进程能够通过copy or send一个capability到另一个进程的capability-list来实现segment的共享，之后每个进程都能够访问这个segment。





### Conventional  VS Capability-based System

Convention and Capability approaches的重要区别体现在进程影响system-wide or process-local objects的能力。

在Conventional System中，一个程序运行在进程自身定义的虚拟地址空间中。程序中的每个procedure调用都有权访问到进程的地址空间，包括段和文件等等，每个procedure在相同的保护环境下执行。

在Capability system中，一个procedure只能够影响到那些capability register被load的objects。

这种能够限制执行环境或者addressing enviroment的能力有很多优点：

对资源的访问控制更加细粒度，也更加灵活





‘









### The Context of an Address

在Capability system中每个object都有唯一的一个identifier。概念上，一个object的identifier从始至终都是唯一的，当object被创建的时候，分配给它一个identifier，这个identifer之后不会再使用（即使相应的object被删除）。



在Conventional system，一个address只有在一个进程中才有效，但是在capability system中，address（capabilities and their identifier）是context-independent，也就是说，capability的解释和一个process使用它是相互独立的。一个capablity中的identifier必须能够在system-wide范围解释。必须要有一个足够大的identifer来编码任何进程在任何时间需要使用的address。这个特性使得capability成为一个能够在进程之间freely passed(自由传递）并用来访问共享数据的东西





addressing on most conventional system

一个address仅仅在一个进程的lifetime之内才有效。





























在capability-based system中，每一个用户、进程都能够访问各自的一组capabilities，表明了





object-based system





























