# DMA接口的使用





## DMA简介

DMA（Direct Memory Access）：直接内存访问。

​	指的是DMA设备不经过CPU可以直接利用物理地址访问物理内存。

​        但是随着发展，DMA直接采用物理地址访问物理内存的方式在面对虚拟化以及虚拟内存空间时显现出很多不灵活，比如DMA要求物理内存必须保证连续。所以，DMAR（DMA Remaping，是Intel为支持虚拟机而设计的IO虚拟化技术）概念出现，在DMAR概念下DMA设备访问的不再是物理地址，而要通过DMA Remapping硬件进行地址转译，在地址翻译的过程会进行权限检查。负责DMA Remapping的硬件是IOMMU。



MMU是支持内存地址虚拟化的硬件，为CPU服务

IOMMU是为DMA设备服务的。**IOMMU**把**设备**访问的虚拟地址转化为物理地址，连接DMA-capable 总线和主存。为了防止设备错误地访问内存，有些IOMMU还提供了访问内存保护机制(检查访问权限)。IOMMU不仅将DMA地址虚拟化，还起到隔离，保护等作用。

![]()



![]()

参考连接： linuxperf.com/?p=67







**注1：**

DMAR(Direct Memory Access Remapping)，是为支持虚拟机而设计的I/O虚拟化技术，，而这个功能的具体实现是采用的IOMMU（Intel采用：Intel Virtualization Technology for Diercted I/O，也简称Intel Vt-d），SMMU（ARM采用）。

**注2：**

**DMAR的设计目标：**

1. 隔离设备，保证安全
2. 地址扩展：使地址空间不足的设备能够访问系统中的左右内存资源
3. 虚拟化：提供地址转换的功能











## DMA的使用

### DMA API

入参：dev（要保证传入的dev是有效的）

#### dev的来源

dts创建或者驱动自行alloc

##### 1. dts创建dev（推荐）

（1）通过dts创建的platform_device节点可以直接用于DMA API使用，可以在prob函数中保存系统传入的				pdev（platform_device），然后使用pdev->dev获取即可

（2）如果设备是dts的子节点（dev在某个父节点之下），需要进行DMA传输相关操作，需要在父节点驱动的prob函数中调用of_platform_device_create()

（3）有了dev之后还需要在prob函数中使用dma_set_mask_coherent设置pdev->dev的dma_mask和dma_coheren_mask，否则alloc/map的结果会异常。

##### 2. 驱动自行alloc出一个dev（不推荐）

（1）platform_device_alloc（char* name，int id）申请platform_dev

（2）调用of_dma_configuration（）配置dev

（3）调用dma_coheren_mask（）设置pdev->dev的dma_mask和dma_coheren_mask



如果dev挂接了iommu/smmu，并且默认使用iommu/smmu访问内存。那么dma_ops是需要切换到iommu_ops的，也就是说dev的dev_ops需要绑定iommu_ops。这样，DMA的访问内存操作就会走dev绑定的iommu_ops（DMA-IOMMU框架），操作的也都是iova，不再是物理地址。



### DMA重映设硬件单元：DRHD

DMA重映设硬件单元：DRHD（DMA Remapping Hardware ）也就是支持DMA重映设的特性的硬件，是IOMMU的核心功能。





### DMA的申请与释放

Intel IOMMU驱动提供了自定义的dma_map_ops，并在初始化时注册在全局的dma_ops

```
const struct dma_map_ops intel_dma_ops = {		//（intel-iommu.c）
         .alloc = intel_alloc_coherent,
         .free = intel_free_coherent,
         .map_sg = intel_map_sg,
         .unmap_sg = intel_unmap_sg,
         .map_page = intel_map_page,
         .unmap_page = intel_unmap_page,
         .mapping_error = intel_mapping_error,
 #ifdef CONFIG_X86
         .dma_supported = dma_direct_supported,
 #endif
 };

```

Intel IOMMU驱动初始化的时候将自定义的ops赋值给全局的dma_ops

```
在函数int __init intel_iommu_init(void)中		//（intel-iommu.c）
#if defined(CONFIG_X86) && defined(CONFIG_SWIOTLB)
         swiotlb = 0;
 #endif
         dma_ops = &intel_dma_ops;	//把IOMMU驱动自定义的ops赋值给全局的dma_ops
 
         init_iommu_pm_ops();
 
         for_each_active_iommu(iommu, drhd) {
                 iommu_device_sysfs_add(&iommu->iommu, NULL,
                                        intel_iommu_groups,
                                        "%s", iommu->name);
                 iommu_device_set_ops(&iommu->iommu, &intel_iommu_ops);
                 iommu_device_register(&iommu->iommu);
         }
 
         bus_set_iommu(&pci_bus_type, &intel_iommu_ops);
         bus_register_notifier(&pci_bus_type, &device_nb);

```



设备驱动在申请DMA内存时，调用全局封装的DMA操作接口，如dma_alloc_coherent，这个函数最终会调到Intel IOMMU提供的DMA接口。

DMA分配的软件流程：

1. 设备驱动调用dma的分配函数
2. Intel IOMMU驱动分配指定大小的内存
3. 从设备对应的domain中分配对应大小的IO虚拟地址空间
4. 将步骤2中分配的内存物理地址和IO虚拟地址进行映设。并将映设之后的值填入到IOMMU硬件指定的各级页表中
5. 返回完成映设的DMA虚拟地址

DMA释放流程：

1. 找到对应设备的IOMMU domain
2. 释放domain中对应的IO虚拟地址资源（DMA虚拟地址资源）
3. 清楚IOMMU硬件指定的各级页表的信息
4. 释放实际物理内存







## References List



vt-directed-io-spec.pdf

Intel vt-d技术规范







