# GNU make 以及Makefile



## Motivation



​        维护一个好的Makefile，对大型项目的开发至关重要，能够节省大量用于编译的时间。设计好的Makefile，当我们重新编译源代码时，只需要编译那些上次编译成功后修改过的文件（也即只需要编译项目的一个delta，而不是整个项目），可以节省大量的编译时间，让开发人员把大部分精力集中到代码开发上。大型项目通常都会有一个专门用于维护Makefile的团队。

​	

​        学习Makefile最重要的是掌握两个概念：目标（object）、依赖（dependency）。



### GNU make简介

make算是一个命令工具，解释Makefile中的规则。

#### make如何工作

**默认情况下，make执行Makefile中的第一个规则，这个规则的第一个目标称为“最终目标”**

make通过比较对应文件（规则的目标和依赖）的最后修改时间，来决定那些文件需要更新，那些文件不需要更新。对需要更新的文件，make就执行数据库中记录的相应命令（在make读取makefile以后会建立一个编译过程的描述数据库，数据库中记录了所有文件之间的关系），对不需要更新的文件，make什么也不做。

make会对那些文件进行编译、连接？

1. 没有被编译过的C源文件
2. 上一次make之后修改过的c源文件
3. 上一次make之后修改了头文件，所有包含此头文件的c源文件

**make递归处理目标的所有依赖**时，按照如下规则：（以处理目标所依赖的.o文件说明）

1. 目标.o文件不存在，使用.o文件对应的规则创建之
2. 目标.o文件存在，但是其所依赖的.c或者.h中任何一个比目标.o“更新”（上一次make之后修改过），则根据相应的规则重新编译生成之
3. 否则，什么也不需要做



#### make解析Makefile文件的过程

##### 两阶段：

- 第一阶段

  读取所有的Makefile文件（包括MAKEFILES变量指定的文件，include指式符指定的文件，以及命令行-f或者--file指定的文件）。

  内建所有的变量，明确规则和隐含规则

  建立所有目标和依赖之间的依赖关系结构链表

- 第二阶段

  根据第一阶段建立的依赖关系链表决定那些目标需要更新并使用对用的规则对其进行更新。

##### make根据makefile规则执行的详细过程

```
1. 依次读取变量“MAKEFILES”定义的makefile文件列表
2. 读取工作目录下的GNUmakefile、makefile、Makefile文件
3. 依次读取工作目录makefile中使用include包含的文件
4. 查找重建所有已读取makefile文件的规则
5. 初始化变量并展开那些需要立即展开的变量和函数，根据预设条件确定指定分支
6. 根据“最终目标”以及其依赖建立依赖关系链表
7. 执行除“最终目标”之外的所有目标的规则
8. 执行“最终目标”所在的规则
```



##### make执行过程中变量和函数的展开过程

“立即展开”：make执行的第一阶段如果对变量和函数进行展开，这个展开为“立即展开”。

“延后展开”：其他时刻对变量或函数的展开

```
IMMEDIATE = DEFERRED
IMMEDIATE ?= DEFERRED
IMMEDIATE := IMMEDIATE
IMMEDIATE += DEFERRED or IMMEDIATE
define IMMEDIATE
		DEFERRED
变量使用+=，如果此前变量是一个简单变量（：=），则认为他是立即展开的，其他情况被认为是延后展开

条件分支的展开是立即展开的：包括ifdef，ifndef，ifeq，ifneq
```





### Makefile简介

Makefile文件描述了整个项目编译、连接的规则。包括：

- 项目中那些文件需要编译以及如何编译
- 需要创建那些库文件以及如何创建库文件
- 如何生成最终的可执行文件

Makefile拥有自己的书写格式、关键字、函数，并且Makefile能够使用shell提供的任何命令。

#### Makefile中包含的内容

- ##### 显式规则

  需要明确指定：目标文件、依赖文件、命令。显式规则在任何时候都能够使用。

- ##### 隐含规则

  

- ##### 变量定义

  几个特殊变量：

  ```
  1. MAKEFILES
  2. MAKEFILE_LIST
  
  ```

  

- ##### 指示符

  指出make程序在读取Makefile文件过程中所要执行的一个动作

  读取给定文件名的文件：

  ```
  include FILENAMES...
  include之后的文件不是用绝对路径表示时的查找规则：
  1）查找使用命令行-l或者--include-dir指定的目录
  2）查找/usr/gnu/include
  3）查找/usr/local/include
  4）查找/usr/include
  -include FILENAMES...表示忽略include文件时的错误信息（GNU支持的方式，其他版本使用sinclude）
  ```

  

  根据一个变量的值，处理或者忽略Makefile中某一特定部分

  定义一个多行变量

- ##### 注释

  注意：以TAB开始的注释行和其他command一样也要交给shell程序解释执行。

#### Makefile文件的命名

make在工作目录，按照顺序查找Makefile文件并执行，查找顺序为：

GNUmakefile

makefile

Makefile(推荐使用)

注：

1. GNUmakefile只有GNU make才可以识别，其他版本的make只识别makefile和Makefile文件
2. 如果找不到任何文件，则make程序执行隐含规则。
3. 也可以使用make -f或者make --file来指定一个或者多个（使用多个-f或者--file）其他命名的Makefile文件。

#### Makefile文件的重建



## Makefile规则

Makfile规则描述了：使用那些文件，通过执行那些命令，来构建那个目标



#### Makefile中规则的语法

```
Makefile中“规则”的一般格式：

target ... : prerequisites...
command
...
...

或者
target .. : prerequisites..；command
command
...
...
```

**target**:<u>规则的目标文件</u>，通常是程序的中间或者最后需要生成的文件。可以是.o文件，也可以是最后的可执行文件，另外还<u>可以是make执行的动作名称</u>（称为伪目标，例如clean。Makefile中把那些没有任何依赖，只有执行动作的目标称为“伪目标”< phony targets>）

**prerequisites**：规则的依赖。生成目标文件所需要的文件列表。依赖分为“常规依赖”和“order-only”依赖：

```
“order-only”依赖的使用举例:
LIBS = libtest.a
foo : foo.c | $(LIBS)
$(CC) $(CFLAGS) $< -o $@ $(LIBS)
make在执行这个规则时,如果目标文件“foo”已经存在。当“foo.c”被修改以后,目标“foo”将会被重建,
但是当“libtest.a”被修改以后。将不执行规则的命令来重建目标“foo”。
就是说,规则中依赖文件$(LIBS)只有在目标文件不存在的情况下,才会参与规则的执行。当目标文件存在时此
依赖不会参与规则的执行过程。

```

**command**:规则的命令行。描述了如何产生或者更新目标文件，是make程序所有执行的动作（任何shell命令或者可在shell下执行的程序）。一个target可以有多个command，每个command一行。

在第一条规则之后的所有以TAB开头的行都作为command，被shell执行

**注意：每个command必须以TAB开始**

​	    **使用(\\)分解多行时，\后边不能有空格**



例子：

```
#sample Makefile
edit : main.o kbd.o command.o display.o \
insert.o search.o files.o utils.o
cc -o edit main.o kbd.o command.o display.o \
insert.o search.o files.o utils.o
main.o : main.c defs.h
cc -c main.c
kbd.o : kbd.c defs.h command.h
cc -c kbd.c
command.o : command.c defs.h command.h
cc -c command.c
display.o : display.c defs.h buffer.h
cc -c display.c
insert.o : insert.c defs.h buffer.h
cc -c insert.c
search.o : search.c defs.h buffer.h
cc -c search.c
files.o : files.c defs.h buffer.h command.h
cc -c files.c
utils.o : utils.c defs.h
cc -c utils.c
clean :
rm edit main.o kbd.o command.o display.o \
insert.o search.o files.o utils.o

```

#### Makefile中的通配符

1. 可以在规则的目标和依赖中使用.
2. 可以出现在规则的命令中，其展开时在shell执行命令之前

除上面两种情况的上下文不能直接使用通配符，而要通过函数“wildcard”来实现





#### 指定变量



```
objects = main.o kbd.o command.o display.o \
insert.o search.o files.o utils.o
```

**objects**作为一个变量，代表所有.o文件的列表。使用这个列表时，可直接用${objects}表示。

#### 自动推导规则

make的隐含规则：将.c文件编译为.o文件。所以对一个目标文件是.o，所依赖文件是.c的规则，可以省略其规则的命令行。例如:

```
# sample Makefile
objects = main.o kbd.o command.o display.o \
insert.o search.o files.o utils.o
edit : $(objects)
cc -o edit $(objects)
main.o : defs.h
kbd.o : defs.h command.h
command.o : defs.h command.h
display.o : defs.h buffer.h
insert.o : defs.h buffer.h
search.o : defs.h buffer.h
files.o : defs.h buffer.h command.h
utils.o : defs.h

.PHONY : clean
clean :
rm edit $(objects)

```

#### 清除文件



#### 目录搜索

##### VPATH变量

make可识别一个特殊变量“VPATH”，通过变量“VPATH”可以指定依赖文件的搜索路径。当规则的依赖文件在当前目录下不存在时间，make会在“VPATH”指定的目录中搜索这些依赖文件。

```
VPATH = stc：../headers

VPATH变量的目录列表可以使用:分隔，也可以使用空格分隔
```

##### vpath关键字





##### 隐含文件和搜索目录



##### 库文件和搜索目录

















### Makefile中的伪目标

伪目标：不代表一个真正的文件名，在执行make时可以指定这个目标来执行其所在规则定一个命令，有时也可将伪目标称之为一个“标签”

#### 使用伪目标的原因：

1. 避免在Makefile中定一个只执行命令的目标和工作目录下的文件出现命名冲突

   ```
   clean:
   	rm *.o temp
   	
   工作目录没有名为clean的文件时：命令总是会被正确执行
   工作目录存在名为clean的文件时：命令不会被执行
   
   ```

   

2. 提高make的效率

   伪目标的另一个使用场合时在make的并行和第归执行过程中

```
对多个目录进行make的方式：

传统方式
SUBDIRS = foo bar baz

subdirs:
	for dir in $(SUBDIRS);do \
		$(MAKE) -C $$dir;\
	done
	缺点：	
	1. 当某个目录下的make失败时，循环不会立即停止
	2. 不能并行的执行make

伪目标的方式
SUBDIRS = foo bar baz
.PHONY : subdirs $(SUNDIRS)
subdirs: $(SUBDIRS)
$(SUBDIRS):
		$(MAKE) -C $@
foo:baz

使用了一个没有命令行的规则foor:baz,含义是在处理foo目录之前需要等待baz目录处理完，在写一个并行Makefile时，目录的处理顺序是需要特别注意的。
```



#### 伪目标的形式

```
.PHONY : clean
clean：
rm *.o temp

```





#### 空目标文件

空目标是伪目标的一个变种，目的也是通过make来执行规则所定义的名两个，和伪目标不同的是，这个目标可以存在一个文件，一般文件内容我们并不关心。

```
print: foo.c bar.c
	lpr -p $?
	touch print
在执行make print的效果是：当print依赖的任何一个文件（foo.c,bar.c）被修改之后，命令lpr -p $?都会被执行，打印这个被修改的文件。
```

#### Makefile中的特殊目标

##### .PHONY : 

目标“.PHONY”的所有的依赖被作为伪目标。伪目标时这样一个目标:当使用make命令行
指定此目标时,这个目标所在规则定义的命令、无论目标文件是否存在都会被无条件执行。

##### .SUFFIXES : 

特殊目标“SUFFIXES”的所有依赖指出了一系列在后缀规则中需要检查的后缀名(就是当前
make需要处理的后缀)。

##### .DEFAULT



##### .PRECLOUS



##### .INTERMEDIATE

##### .SECONDARY

##### 其他







## 预备知识：



编译:



连接：



静态库：又称为文档文件（Archive File）。是多个.o文件的集合。

共享库：



1、关于命令的变量。
AR   函数库打包程序。默认命令是“ar”。
AS
汇编语言编译程序。默认命令是“as”。
CC
C语言编译程序。默认命令是“cc”。
CXX
C++语言编译程序。默认命令是“g++”。
CO
从 RCS文件中扩展文件程序。默认命令是“co”。
CPP
C程序的预处理器（输出是标准输出设备）。默认命令是“$(CC) –E”。
FC
Fortran 和 Ratfor 的编译器和预处理程序。默认命令是“f77”。
GET
从SCCS文件中扩展文件的程序。默认命令是“get”。
LEX
Lex方法分析器程序（针对于C或Ratfor）。默认命令是“lex”。
PC
Pascal语言编译程序。默认命令是“pc”。
YACC
Yacc文法分析器（针对于C程序）。默认命令是“yacc”。
YACCR
Yacc文法分析器（针对于Ratfor程序）。默认命令是“yacc –r”。
MAKEINFO
转换Texinfo源文件（.texi）到Info文件程序。默认命令是“makeinfo”。
TEX
从TeX源文件创建TeX DVI文件的程序。默认命令是“tex”。
TEXI2DVI
从Texinfo源文件创建军TeX DVI 文件的程序。默认命令是“texi2dvi”。
WEAVE
转换Web到TeX的程序。默认命令是“weave”。
CWEAVE
转换CWeb 到 TeX的程序。默认命令是“cweave”。
TANGLE
转换Web到Pascal语言的程序。默认命令是“tangle”。
CTANGLE
转换CWeb 到 C。默认命令是“ctangle”。
RM
删除文件命令。默认命令是“rm –f”。

2、关于命令参数的变量

下面的这些变量都是相关上面的命令的参数。如果没有指明其默认值，那么其默认值都是空。
ARFLAGS
函数库打包程序AR命令的参数。默认值是“rv”。
ASFLAGS
汇编语言编译器参数。（当明显地调用“.s”或“.S”文件时）。
CFLAGS
C语言编译器参数。
CXXFLAGS
C++语言编译器参数。
COFLAGS
RCS命令参数。
CPPFLAGS
C预处理器参数。（ C 和 Fortran 编译器也会用到）。
FFLAGS
Fortran语言编译器参数。
GFLAGS
SCCS “get”程序参数。
LDFLAGS
链接器参数。（如：“ld”）
LFLAGS
Lex文法分析器参数。
PFLAGS
Pascal语言编译器参数。
RFLAGS
Ratfor 程序的Fortran 编译器参数。
YFLAGS
Yacc文法分析器参数。





























