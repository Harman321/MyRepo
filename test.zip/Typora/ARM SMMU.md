# SMMU

### 1 SMMU提供的Software Interface

1. Memory-based data structure

   用来映射devices到translation table

2. Memory-based circular buffer queues

   Command queue：

   Event queue：event/falut report

   PRI queue：

3. A set of register

   有些寄存器是Secure World专用的

   用来实现SMMU全局的配置，以及discovery

## 2. 一些基本概念

### 2.1 StreamID

StreamID用来区分正在使用SMMU的设备，通过StreamID能够定位到StreamTable中的一个表项（Stream Table Entry：STE），这个表项对应一个物理device的Configuration。



每个SMMU对应一个StreamID namespace

一个物理Device可能有若干个StreamID



StreamID是由软件生成的





#### Secure World Or Normal World‘s StreamID namespace

输入到SMMU的StreamID根据**SEC_SID**标志，来区分输入的StreamID是指向的Secure Word或者Normal World中的StreamID namespace。

 

### 2.2 SubStreamID

等价于PCIe PASID，SubStreamID是SMMU stage1 translation的一个可选项，





## 3. DataStructure

### 3.1 SMMU中的队列：Command and Event

SMMU中的队列被设计为circular buffer in memory，能够同时被input to and output from SMMU使用。一个编程口拥有一个command queue for input以及一个event queue（或者一个PRI queue） for output。所有队列的工作模式都是：生产者-消费者模型。

#### 队列数据结构设计

PROD index：

CONS index：

warp bit：

#### 队列状态判断

如果PROD index和CONS index相等，并且他们的wrap bit相等，队列为空，只有Procedure

如果PROD index和CONS index相等，并且他们的wrap bit不相等，队列为满，只有Consumer

如果PROD index和CONS index不相等，或者他们的wrap bit不相等，队列既可有Procedure，也可有Consumer



#### 队列初始化

队列必须初始化为下列4种一致性情况中的一种：

-  PROD.WR == CONS.RD and PROD.WR_WRAP == CONS.RD_WRAP, representing an empty queue.
-  PROD.WR == CONS.RD and PROD.WR_WRAP != CONS.RD_WRAP, representing a full queue.
-  PROD.WR > CONS.RD and PROD.WR_WRAP == CONS.RD_WRAP, representing a partially-full queue.
-  PROD.WR < CONS.RD and PROD.WR_WRAP != CONS.RD_WRAP, representing a partially-full queue.

其他的情况会导致一些问题：具体问题参考Reference List中的[1]

#### 示例：

例如：一个由128个entries的队列意味着：

队列index为7bit

PROD和CONS寄存器的[6:0]为队列的索引

PROD和CONS寄存器的bit[7]为wrap标志



下图表示了一个循环队列的生命周期：

当proceduring或者consuming一个entry的时候，software必须只对index进行递增（除非递增会导致warp to the start），index决不能向后倒退。

![](pic/mmu/queue.png)



主要是Configuration Data Structure：Stream Table， Context Descriptor

### 3.2 Stream Table Entry

![](/media/kabu-nuo/1A702686702668A9/Users/Administrator/Desktop/Typora/pic/mmu/table.png)

### 3.3 Context Descriptor

![](/media/kabu-nuo/1A702686702668A9/Users/Administrator/Desktop/Typora/pic/mmu/descriptor.png)











### 3.4 两种Stream Table

##### Liner Stream Table

所有的SMMU实现都支持此种格式

![](pic/mmu/linear.png)

##### 2-Level Stream Table

![](pic/mmu/two_level.png)

### StreamIDs to Context Discriptor



Translate过程如果需要Stage1，则STE使用STE.S1ContextPtr指出一个或多个内存中的CD（Context Discriptor）的地址，具体格式由STE.S1FMT和STE.S1CDMAX配置。

- ​	一个单独的CD
	 	single-level table的基地址
	 ​	first-level，L1，table of L1 CDs的基地址

	​	

CD（Context DIscrpitor）关联着（1）Stage1（VA-->IPA） Translate Table的基地址指针；（2）每个StreamID的Confiruration；（3）ASID。Translate过程如果需要Stage2，STE同时包含着（4）Stage2（IPA-->PA）Translation Table的基地址指针；（5）VMID。

![](pic/mmu/example_cd.png)



![](pic/mmu/severl_cd.png)









### Configration And Translation Lookup

#### Configuration Lookup

##### 输入：

- SMMU全局的寄存器配置
- StreamID
- SubStreamID（可能会有）

##### 过程：

​		

##### 输出：

能够locate translation的 Stream或者SubStream-Specific Configuration

（1）Stage1 转换表的基地址指针，ASID，

（2）Stage2转换表的基地址指针，VMID，

（3）Stream-Specific Propertits：例如StreamWorld（Exception Level、translation regime等）

#### Translation Lookup

##### 输入：

- input address
- Stream World（Stream Security State，Exception Level），ASID，VMID

##### 过程



##### 输出

（1）final physical address

![](pic/mmu/lookup.png)





#### Transaction Attribute:

##### Incoming

- Permission-related attribute:

  Instruction/data,privileged/umpriviliged,read/write property

- Other attribute:

  memeory type

  shareability

  cache hints

  

##### Two-Stage Transaction

Overrides







### Translation Table Discriptors

#### SMMU使用的地址种类

1. Input Address Size(from the system)

   64bits

2. Intermediate Address Size(ISA)

   ISA反映了由Stage1产生的，最终输入到Stage2的最大可用的IPA大小

   IAS = MAX((SMMU_IDR0.TTF[0] == 1 ? 40 : 0), (SMMU_IDR0.TTF[1] == 1 ? OAS : 0));

   40bits的IPA需要支持AArch32中的LPAE translation，在AArch64中，把最大IPA大小限制为最大的PA大小。

3. Output Address Size(OAS)

   OAS反映AArch64 Translation最后Stage 输出的最大可用PA大小，必须匹配系统的物理地址大小。

#### 地址合法性检查

##### Stage1：

Input--->Stage1:输入到Stage1的地址被认为是VA：

如果Stage1没有把VA bypassed，Stage1将会对VA进行检查：检查VA是否越界，这个范围由Stage1对应的CD定义。

​	如果越界会导致Stage 1 Translation Fault

​		1. AArch32：range配置为 PLAE，最大为32bit

​		2. AArch64，range由T0SZ和T1SZ域决定

​			SMMUv3.0和SMMUv3.1的range也不同

​	如果Stage的输出address超过了有效的IPA大小范围，会导致Stage1 Address Size Fault

​		1. AArch32：IPA size为40bits

​		2. AArch64：由CD的IPS域决定

如果Stage把VA bypassed，那么input address直接作为IPA传递给Stage2

##### Stage2：

Stage2收到一个IPA，如果没有bypassed，则会进行下面的地址合法性检查，这个返回由STE中S2T0SZ域配置的range决定

​	如果IPA的size越界，则会导致Stage2 Translation fault

​		1.AArch32：

​		2.AArch64：

​	如果Stage2的输出address超过了有效的PA大小范围，则会导致Stage2 Address Size Falut

​		1.AArch32：

​		2.AArch64：		

#### SMMU发起的访问地址的大小

SMMU为了以下目的发起对system的访问：

-  Configuration structure access (STE, CD)：用于对SMMU配置的数据结构
-  Queue access (Command, Event, PRI)：各种队列
-  MSI interrupt writes：
-  Last-stage translation table walks：

SMMU在访问这些数据结构的时候可能会使用超出地址范围的address。因此，如果配置寄存器、command fileds以及structure fileds使用了超过物理地址大小的address，他们可能会被截断为OSA或者PA大小。









### SMMU支持两种Sercurity states

ARM体系结构支持两种Sercurity States，**每个States中都有一个物理内存地址空间**：

- Secure States（NS=0）
- Non-Secure States（NS=1）

SMMU通过SMMU_S_IDR1.SECURE_IMPL来标志是否支持ARM Security Model：

- SMMU_S_IDR1.SECURE_IMPL == 0：

  1）SMMU仅仅支持一种Secure State：Non-Secure State

  2）SMMU只能产生Non-Secure（NS=1）transaction

  3）SMMU支持stage1是可选的

- SMMU_S_IDR1.SECURE_IMPL == 1：

  1）SMMU支持两种Secure State：Secure State 和 Non-Secure State

  2）SMMU_S_*寄存器配置Secure State

  3）SMMU支持Stage1，might支持Stage2

  4）SMMU既能产生Secure（NS=0）也能产生Non-Secure（NS=1）translation to memory system

#### 安全状态确定SSD：Secure State Determinination

SSD（Secure State Determinination）用来决定给定的transaction stream	





## Reference List:

[[1] ARM SMMU官方设计手册](https://developer.arm.com/products/architecture/a-profile/docs/ihi0070/latest/arm-system-memory-management-unit-architecture-specification-smmu-architecture-versions-30-31-and-32)



































































































### VA/IPA/PA

物理地址PA：由硬件定义，直接定义物理存储的内存空间。

虚拟地址VA：由软件定义，利用页表能够实现不同内存区域的属性以及访问权限。



### 内存虚拟化

主要是为了解决Normal World侧，Guest Operating System访问真实物理内存的问题。没有虚拟化的时候，例如Secure World OS中操作的物理内存直接对应到真实的物理内存，但是Normal World中VMM上层运行多个Guest OS，所有的Guest OS同样和Secure World OS一样，他们自己认为自己操作的是真实的物理内存，但实际却不是，需要将他们的“伪PA”------>IPA------->真实PA。其中

“伪PA”------>IPA：页表翻译的Stage 1阶段

IPA------->真实PA：Hyp层  页表翻译的Stage2 阶段



VMM or Hypervisor完成硬件资源的共享、隔离以及切换



![](pic/mmu/trustzone.png)







### MMU（Memory Management Uint :存储管理单元）

#### 功能

- 负责 CPU提供的VA --->  PA

  PA--->TLB命中？:返回PA：walk page table and return PA && uptade TLB

- 控制存储器的访问权限（将VA通过页表映射到不同的真实物理内存的不同区域，以达到内存隔离或者内存保护机制，从而实现对存储器访问权限的控制）

MMU的主要构件：TLB（转换后援缓冲器）



#### 不同架构下MMU的实现不同

##### AArch32：

- 页表使用32位短描述符格式

- 最多支持2级页表转换

- 最大输出40位地址

- 支持的段页格式：

  SuperuperSection（16MB），Section（1MB），LargePage（64KB），SmallPage（4KB）

- 页表转换过程














