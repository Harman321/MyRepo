# ARM页表简介

## ARM两级页表概述

mmu硬件执行虚拟地址到物理地址的转换，其中MMU使用的页表结构如下 ：



![](pic/mmu/mmu.jpeg)

 以上是arm的页表框图的典型结构：即是二级页表结构：

 其中第一级页表（L1）是由虚拟地址的高12bit（bits[31：20]）组成,所以第一级页表有4096个item，每个item占4个字节，所以一级页表的大小为16KB，而在第一级页表中的每个entry的最低2bit可以用来区分具体是什么种类的页表项，2bit可以区分4种页表项，具体每种页表项的结构如下：

![](pic/mmu/L1.png)

但在linux内核启动的初始化阶段，临时建立页表（initial page  tables）以供linux内核初始化提供执行环境，这时L1的页表项使用的就是第二种页表项（section  enty），他直接映射的是1M的内存空间。具体的可以参考arch/arm/kernel/head.S中的__create_page_tables函数

### L1级页表

L1页表的页表项[31:20]主要有两大类:

- 指向第二级页表（L2页表）的基地址
- 指向1MB的物理内存

 在L1页表中每个表项可以覆盖1MB的内存，由于有4096K个选项（item），所以总计可以覆盖4096K*1MB=4GB的内存空间。



### L2级页表









### mmu硬件执行虚拟地址转物理地址的过程

Single-level Page Table Walk

![](pic/mmu/single_level.png)

以上在初始化过程使用的临时页表（initial page  tables），在内核启动的后期会被覆盖掉，即在paging_init--->map_lowmem函数中会重新建立页表，该函数为物理内存从0地址到低端内存（lowmem_limit）建立一个一一映射的映射表。所谓的一一映射就是物理地址和虚拟地址就差一个固定的偏移量，该偏移量一般就是0xc0000000(Linux中)



Two-Step-Level  Page Table Walk 

![](pic/mmu/two_step.png)





https://blog.csdn.net/czg13548930186/article/details/74979222

https://blog.csdn.net/cosmoslhf/article/details/37964575

## Reference Lists



1. [ARM MMU页表框架](https://blog.csdn.net/czg13548930186/article/details/74979222)
2. 

