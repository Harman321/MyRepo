# CI持续集成环境搭建

# 	         ——静态检查工具篇



## 静态检查工具



### PC-Lint

PC-Lint：C/C++静态检查，保证warring、error、高风险info清零





### Simian

Simian：代码重复度检查

在jenkins上执行Simian检查，检查代码重复度信息，生成Simian报告，并在jenkins上展示，以及上报数据中心。





支持个人级和版本级的检查







### Metrics

Metrics：文件重复度检查





### cschecker

危险函数检查/冗余代码检查







### CodeDEX

CodeDEX（coverity、fortity）



### SourceMonitor

总体平均圈复杂度<=5

新增函数最大圈复杂度<10

平均函数代码行<=30

新增/修改代码单函数代码行<=50







### DFX测试

DFX专项部分：安全、性能、压力、可靠





### LLTCodeCheck

LLT：全量代码LIT















冒烟测试



HLT：全量自动化功能HLT



设置代码提交提交门限





代码统计CCT/sharpcounter

架构检查SAI



开源及第三方软件风险扫描





函数圈复杂度/函数代码量/代码行

LIT代码语句用例覆盖率

## References List



[ [1] CI持续集成环境构建](http://www.cnblogs.com/kevingrace/p/5651447.html)

