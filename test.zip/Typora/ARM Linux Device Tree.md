# ARM Linux Device Tree

## 一、简介

设备树（Device Tree）是一种描述硬件的数据结构，由一系列命名的节点（node）和属性（property）组成。用于描述包括但不仅限于下述硬件信息：

- CPU数量和类别
- 内存基地址和大小
- 总线和桥
- 外设连接
- 中断控制器和中断使用情况
- Clock控制器和Clock使用情况
- GPIO控制器和GPIO使用情况

设备树实际就是描述出了一个电路板上CPU、总线、设备组成的树。BootLoader会将设备树传递给内核。



## 二、一些基本概念

### DTS（Device Tree Source）

.dts是一种ASCII文本格式的Device Tree描述。在ARM Linux中一个.dts文件对应一个machine。一般放置在arch/arm/boot/dts目录下。而.dtsi文件存放了多个dts文件公用的部分（类似C中的头文件）,可以在.dts文件中通过#include “xxx.dtsi”将一个.dtsi文件包含进来。

### DTC（Device Tree Compiler）

将.dts编译为.dtb的工具，dtc工具位于（script/dtc）



通过dtc工具把dts变为dtb

`$ scripts/dtc/dtc -I dts -O dtb /path/my_tree.dtb /arch/arm/boot/dts/my_tree.dts`

通过dtc工具把dtb变为dts

`$ scripts/dtc/dtc -I dtb -O dts  /arch/arm/boot/dts/my_tree.dts  /path/my_tree.dtb`

### DTB（Device Tree Blob）

.dts被dtc工具编译之后的二进制格式的设备树描述文件。可由Linux内核解析，



### Binding

Device Tree中节点和属性具体是如何描述硬件细节的，需要参考（Documentation/devicetree/binding）下的.txt文档。



### BootLoader

为了使能设备树，需要编译Uboot的时候在config文件加入

#define CONFIG_OF_LIBFDT

在Uboot中可以从NAND,SD或者TFTP任何介质中将.dtb二进制文件加载到内存地址.



## 三、Device Tree实例分析

### 文件格式

```
/{		//一个root节点，root节点下边包含若干个子节点node1，node2
	 node1 { 		//node1由一系列key-value组成，也可以包含子节点child-node，child-node2
		a-string-property = "A string" ;	//属性可以是一个字符串
		a string-list property = "first string" , "second string" ;	//属性可以是一个字符串数组
		a byte-data property = [0x01 0x02 0x03 0x04] ;	//属性可以是二进制数
		child-node1 {
			first child property ;
			second-child property = <1> ;
			a string property = "Hello World" ;
		}
		child-node2{
		} ;
	} ; 
	node2 {
		an empty property	//属性可以为空
		a cell property = <1,2,3> ;//属性可以是Cells（由u32组成）
	}
}

```

dts文件由若干个Node组成，每个Node由Property组成，每个Property是一个Key-Value对儿，其中

##### keys：

name

compatible

address-cell

size-cell

regs

region

.....

##### values：

value可以为空或者下述常用类型

- text-string：“string-property = “a string value”
- cell：”cell-property = <0x000，0x0001，0x0002，0x0004>“
- binary-property： “binary-property = [0x01,0x02.0x04]”
- mixed-property: "mixed-property = "a string, <0x01,0x02,0x03>,[0x01,0x02,0x03]"
- string-list: "string-list =  "red,blue,yellow"

### Sample Machine

姑且想象有这么一台机器，它由"Acme"出产，名为"Coyote's Revenge", 配置如下:

    32bit ARM CPU
    **处理器的本地内存总线**连接如下设备：串口，SPI总线控制器，I2C控制器，中断控制器以及外部总线桥
    256MB SDRAM 位于地址：0x0
    两个串口，位于地址：0x101F1000 及 0x101F2000
    GPIO控制器位于地址：0x101F3000
    SPI控制器位于地址：0x10170000，在它下面连接了如下设备：
        MMC卡槽，其SS脚连接了GPIO1
    外部总线桥上接了如下设备：
        SMC91111 以太网控制器，位于地址：0x10100000
        I2C控制器，位于地址：0x10160000，在它下面连接了如下设备：
            Maxim DS1338实时时钟，I2C地址为0x58
        64MB NOR flash 位于地址：0x30000000

**初始结构**

第一步是要建立一个基本结构来使得这颗设备树能描述对应的Machine
/ {
    compatible = "acme,coyotes-revenge";
};

**compatible属性**

这个属性用于执行系统名，通常它是以 "厂商,型号" 这样的字符串形式存在。它能准确的描述对应的设备的特征。

CPU描述
下一部就是描述每一个CPU了。在cpus节点中，每个CPU就是一个子节点。这种情况在多核的ARM Cortex A9系统中很常见。
/ {
    compatible = "acme,coyotes-revenge";
    cpus {
        cpu@0 {
            compatible = "arm,cortex-a9";
        };
        cpu@1 {
            compatible = "arm,cortex-a9";
        };
    };
};
每个cpu的子节点中有个compatible属性，它描述了CPU的具体型号，形式通常也是 "厂商，型号" 
当然，CPU的细节不是这么一个compatible属性能描述清楚的，后面我们会再逐步加入。

#### name节点名

有必要为节点的命名讲几句。每个节点的名字都应该是这样的形式： <name>[@<unit-address>]
尖括号是必须的，方括号是可选的。
<name> 是一个ASCII字符串，长度不超过31个字符。通常，节点名都是与设备的类型有关联的。比如，3com的以太网卡，通常节点名就叫 ethernet 而不叫 3com509
<unit-address>被作为节点名的一部分时，用来描述设备的地址。通常，unit-address就是设备的寄存器地址，这个地址是被列举在节点的reg属性中的。在后文中我们会介绍reg属性的内容。
同级别的兄弟节点的节点名必须唯一（不可重名），但如果name一致而address不一致则是正常情况（比如，serial@101f1000 与 serial@101f2000）。
关于节点的命名规则细节，请参考ePAPR文档的2.2.1节。

设备
系统中的每个设备都对应着设备树中的一个节点。好了，下一步我们就是为每个设备都加上对应的节点。
目前，我们仅为每个设备增加一个空节点，待后面介绍了中断号及地址范围的概念后再行补充。
/ {
    compatible = "acme,coyotes-revenge";

    cpus {
        cpu@0 {
            compatible = "arm,cortex-a9";
        };
        cpu@1 {
            compatible = "arm,cortex-a9";
        };
    };
    
    serial@101F0000 {
        compatible = "arm,pl011";
    };
    
    serial@101F2000 {
        compatible = "arm,pl011";
    };
    
    gpio@101F3000 {
        compatible = "arm,pl061";
    };
    
    interrupt-controller@10140000 {
        compatible = "arm,pl190";
    };
    
    spi@10115000 {
        compatible = "arm,pl022";
    };
    
    external-bus {
        ethernet@0,0 {
            compatible = "smc,smc91c111";
        };
    
        i2c@1,0 {
            compatible = "acme,a1234-i2c-bus";
            rtc@58 {
                compatible = "maxim,ds1338";
            };
        };
    
        flash@2,0 {
            compatible = "samsung,k8f1315ebm", "cfi-flash";
        };
    };
};
上面这棵树中，系统中的每个设备都被添加了一个节点，而且节点的结构真实反应了设备是如何挂载在系统上的。比如，ethernet，i2c等节点是external-bus的子节点，rtc设备是i2c总线下的子节点。通常，设备树的结构都是以CPU的视角来反应出来的。
上面这棵树还有几点不足，它缺少了设备的关键信息。这些信息将在后文中逐步添加上去。
关于上面这颗树，我们还需要注意：

    每个设备节点都一个compatible属性
    flash这个节点的compatible属性有两个字串，下面一节将介绍为什么这么写。
    在前文中曾提到：节点名反应的是设备类型而非设备型号。请参考ePAPR的2.2.2节中列出的常用节点名。

#### 理解compatible属性

每个设备节点都需要一个compatible属性。

compatible属性是系统查找对应的设备驱动程序的一个关键值，系统就是根据它的值来查找这个设备应该使用哪一个驱动的。
compatible属性的值是一个字串表。第一个字串以"厂商,型号"的形式描述了准确的设备信息。后面一个字串则表示与它兼容的其他设备。
比如，Freescale MPC8349有一个串口设备是由National Semiconductor ns16550寄存器接口来实现的。所以对MPC8349的串口设备，它的compatible属性我们就可以这样写：compatible = "fsl,mpc8349-uart", "ns16550"，对于这样的情况，fsl,mpc8349-uart准确描述了这个设备，而ns16550则说明了这个设备是与National Semiconductor ns16550寄存器接口兼容的。
注：ns16550它没有厂商名这个信息，这是由于历史原因。但所有新创建的compatible属性都应该有厂商名这个前缀。
compatible属性的这一特性，使得我们可以让新设备使用系统中已有的旧驱动。
警告：不要在compatible属性中使用通配符，如 "fsl,mpc83xx-uart" 或类似的。因为半导体厂商会不定期的更新他们的设计这会破坏你的通配符规则。选择具有更好兼容性的方案才是正途。

#### 地址是怎么工作的

可寻址设备是通过使用以下属性来将地址信息编码到设备树中的：

    reg
    #address-cells
    #size-cells

**可寻址设备**通过reg属性来**获取寄存器相关的地址信息列表**，reg属性的形式如下：
reg = <address1 length1 [address2 length2] [address3 length3] ... >
每一组address length对应了设备所使用的一个地址区域。
address是一个list，其中包含一个或多个32位整数，我们把它叫做 cells。同理，length也是一个list，可以是多个cell或为空。

由于address和length的长度都是不固定的，所以有了#address-cells和#size-cells这两个属性。这两个属性被放到父节点中用于描述每个区域有几个cell。简单的说，就是reg属性需要配合父节点的#address-cells和#size-cells来配合使用。为了弄明白它们是怎么工作的，下面我们就来为这个设备加上地址相关的属性，先从CPU开始。

##### CPU地址

CPU节点的地址用法是最简单的。每个CPU被分配了唯一的ID号，而且这个没有size。
    cpus {
        #address-cells = <1>;
        #size-cells = <0>;
        cpu@0 {
            compatible = "arm,cortex-a9";
            reg = <0>;
        };
        cpu@1 {
            compatible = "arm,cortex-a9";
            reg = <1>;
        };
    };
在上面的cpus节点中，#address-cells被设为了1，#size-cells则被设为了0，这就表示它的子节点中的reg属性是一个32位整数的address，而且没有size部分。
在上面的例子中，你可能注意到了节点名中的寄存器地址与reg数值一样。
约定俗成的做法是，如果一个节点有reg属性，则节点名中也需要包含unit-address这个部分，而unit-address的数值则是reg属性的第一个address值。

##### 内存映射设备

与cpu节点中的这种单地址不同，内存映射设备所分配的是一个地址范围，而这个地址范围则是由#size-cells和节点中的reg属性的size区域来决定的。下面这个例子中，每个address是1个cell（32bit），且每个长度值也是一个cell。在32位系统中#size-cells通常就是这样设置为1的。而早64位系统中，#address-cells和#size-cells则通常设置为2。

    / {
    
        #address-cells = <1>;
        #size-cells = <1>;
    ...
    
    serial@101f0000 {
        compatible = "arm,pl011";
        reg = <0x101f0000 0x1000 >;
    };
    
    serial@101f2000 {
        compatible = "arm,pl011";
        reg = <0x101f2000 0x1000 >;
    };
    
    gpio@101f3000 {
        compatible = "arm,pl061";
        reg = <0x101f3000 0x1000
               0x101f4000 0x0010>;
    };
    
    interrupt-controller@10140000 {
        compatible = "arm,pl190";
        reg = <0x10140000 0x1000 >;
    };
    
    spi@10115000 {
        compatible = "arm,pl022";
        reg = <0x10115000 0x1000 >;
    };
    
    ...

};
每个设备被分配了一个基地址以及一个size。上面的例子中，gpio设备被分配了两个地址段： 0x101f3000~0x1013fff 以及 0x101f4000~0x101f4fff。

有些设备在系统总线上的地址不连续。比如，一个设备可能通过不连续的片选线连接在外部总线上。
通过在父节点设置合适的#address-cells和#size-cells，地址映射机制可以准确的描述内存映射关系。下面的代码中展示了一个不同片选信息在是如何使用的。


    external-bus {
            #address-cells = <2>
            #size-cells = <1>;
      ethernet@0,0 {
            compatible = "smc,smc91c111";
            reg = <0 0 0x1000>;
        };
    
        i2c@1,0 {
            compatible = "acme,a1234-i2c-bus";
            reg = <1 0 0x1000>;
            rtc@58 {
                compatible = "maxim,ds1338";
            };
        };
    
        flash@2,0 {
            compatible = "samsung,k8f1315ebm", "cfi-flash";
            reg = <2 0 0x4000000>;
        };
    };
上面的例子中，external-bus使用了两个cell来描述address；一个表示片选号，另一个表示与片选基地址间的偏移量。length区域则用了一个cell来描述。在这个例子中，每个reg节点包含3个cell，分别是：片选号，偏移量，长度

##### 非内存映射设备

还有一些设备在总线上并不是不是内存映射型的。他们可以有地址空间，但他们没有通过CPU直接访问地址空间的能力。取而代之的是他们的父设备驱动拥有间接访问内存空间的能力。

以I2C设备（不是I2C总线哦）为例子，每个设备被分配了一个地址，没有length这个字段。看起来实际上与cpu的地址分配很相似。
        i2c@1,0 {
            compatible = "acme,a1234-i2c-bus";
            #address-cells = <1>;
            #size-cells = <0>;
            reg = <1 0 0x1000>;
            rtc@58 {
                compatible = "maxim,ds1338";
                reg = <58>;
            };
        };

#### Ranges（地址变换）

上文已经讨论过了我们如何分配地址给设备，但是这个所谓的地址仅仅是在设备节点中的本地地址。它无法描述该如何将这些本地的地址映射到CPU能访问的地址空间中。
根节点中一定有描述CPU的地址空间。子节点所用的地址空间就来自与CPU的地址空间，所以不需要进行额外的地址映射。
如：serial@101f0000 就是直接分配的地址0x101f0000。
**如果一个节点它不是根节点下的子节点，那么它就不能用CPU的地址空间。为了能将一个地址空间的地址映射到另一个地址空间，range属性被创造出来了。**
下面是在一个简单的设备树中增加range属性。


    / {
        compatible = "acme,coyotes-revenge"
        #address-cells = <1>;
        #size-cells = <1>;
        ...
        external-bus {
            #address-cells = <2>
            #size-cells = <1>;
            ranges = <0 0  0x10100000   0x10000     // Chipselect 1, Ethernet
                      1 0  0x10160000   0x10000     // Chipselect 2, i2c controller
                      2 0  0x30000000   0x1000000>; // Chipselect 3, NOR Flash
    
        ethernet@0,0 {
            compatible = "smc,smc91c111";
            reg = <0 0 0x1000>;
        };
    
        i2c@1,0 {
            compatible = "acme,a1234-i2c-bus";
            #address-cells = <1>;
            #size-cells = <0>;
            reg = <1 0 0x1000>;
            rtc@58 {
                compatible = "maxim,ds1338";
                reg = <58>;
            };
        };
    
        flash@2,0 {
            compatible = "samsung,k8f1315ebm", "cfi-flash";
            reg = <2 0 0x4000000>;
        };
    };
};
上面的例子中，ranges属性就定义了一个地址转换规格。在这个表中的每个节点表示一个地址转换关系。
ranges属性中每个字段的大小取决于当前节点的#address-cells，父节点的#address-cells以及当前节点的#size-cells。
比如上面的例子中，external-bus节点的地址长度是2，它的父节点的地址长度是1，size长度是1。所以ranges中的三个地址规则可以这样解读：

    CS0，偏移量为0的本地地址被映射到父节点地址空间的 0x10100000~0x1010ffff
    CS1，偏移量为1的本地地址被映射到父节点地址空间的 0x10160000~0x1016ffff
    CS2，偏移量为0的本地地址被映射到父节点地址空间的 0x30000000~0x31000000

更方便的是，如果父节点与子节点的地址空间完全匹配，则子节点可以只定义一个空的ranges属性。
空ranges属性所表示的意思就是子节点的地址空间与父节点地址空间是1：1的映射关系。
你可能会问：为什么上面会写1：1的映射关系？有些总线结构（如PCI总线）拥有自己独立的地址空间，但需要向操作系统开放。还有些设备有DMA引擎，这就需要知道总线上的实际地址。还有些时候几个设备因为使用同样的物理地址空间而需要组合在一起。在硬件设计以及操作系统的大量特性上决定了地址映射是不是1：1的映射关系。
也可能还注意到了上文中的i2c@1,0节点中没有ranges属性。原因是I2C总线不像外部总线，它的地址空间并没有映射到CPU的地址空间中去。实际上，CPU对rtc@58的访问是通过i2c@1,0这个设备来间接达成的。没有ranges属性正表明了这个设备是不能直接访问除父节点外的任何设备的特性。

#### 中断是怎样工作的

不想地址空间映射表那样是遵循设备树的自然结构的（父传子），中断信号可以被machine中的任何设备产生或终止。中断信号独立与设备树将各个节点关联起来。描述一个中断需要4个属性：

    interrupt-controller 这个属性没有值，他表示这个节点是一个接收中断信号的设备
    #interrupt-cells 这个属性是一个interrupt-controller节点的属性，他说明了这个 interrupt-controller的每个中断说明符（interrupt specifier）有几个cells，类似#address-cells 与 #size-cells的作用
    interrupt-parent 这是一个设备节点的属性，用于表明当前设备的中断是属于哪一个interrupt-controller的，如果没有这个属性，则继承其父节点的interrupt-parent属性
    interrupts 这是一个设备节点的属性，他是 中断说明符 列表，每一个 中断说明符 表示此设备的一个中断信号输出。

中断说明符是由一个或多个cell数据（#interrupt-cells ）来描述一个设备是与哪一个中断信号输入设备相连接的。多数设备都只有一个中断信号输出，如下面的例子，但也有可能存在一个设备有多个中断信号输出的情况。中断说明符的含义与具体的中断控制器（ interrupt-controller）有关。每个中断控制器都可以决定它的输入信号的中断说明符有几个cell数据。
下面的代码中为我们的Coyote's Revenge添加了中断连接：


    / {
        compatible = "acme,coyotes-revenge";
        #address-cells = <1>;
        #size-cells = <1>;
        interrupt-parent = <&intc>;
    cpus {
        #address-cells = <1>;
        #size-cells = <0>;
        cpu@0 {
            compatible = "arm,cortex-a9";
            reg = <0>;
        };
        cpu@1 {
            compatible = "arm,cortex-a9";
            reg = <1>;
        };
    };
    
    serial@101f0000 {
        compatible = "arm,pl011";
        reg = <0x101f0000 0x1000 >;
        interrupts = < 1 0 >;
    };
    
    serial@101f2000 {
        compatible = "arm,pl011";
        reg = <0x101f2000 0x1000 >;
        interrupts = < 2 0 >;
    };
    
    gpio@101f3000 {
        compatible = "arm,pl061";
        reg = <0x101f3000 0x1000
               0x101f4000 0x0010>;
        interrupts = < 3 0 >;
    };
    
    intc: interrupt-controller@10140000 {
        compatible = "arm,pl190";
        reg = <0x10140000 0x1000 >;
        interrupt-controller;
        #interrupt-cells = <2>;
    };
    
    spi@10115000 {
        compatible = "arm,pl022";
        reg = <0x10115000 0x1000 >;
        interrupts = < 4 0 >;
    };
    
    external-bus {
        #address-cells = <2>
        #size-cells = <1>;
        ranges = <0 0  0x10100000   0x10000     // Chipselect 1, Ethernet
                  1 0  0x10160000   0x10000     // Chipselect 2, i2c controller
                  2 0  0x30000000   0x1000000>; // Chipselect 3, NOR Flash
    
        ethernet@0,0 {
            compatible = "smc,smc91c111";
            reg = <0 0 0x1000>;
            interrupts = < 5 2 >;
        };
    
        i2c@1,0 {
            compatible = "acme,a1234-i2c-bus";
            #address-cells = <1>;
            #size-cells = <0>;
            reg = <1 0 0x1000>;
            interrupts = < 6 2 >;
            rtc@58 {
                compatible = "maxim,ds1338";
                reg = <58>;
                interrupts = < 7 3 >;
            };
        };
    
        flash@2,0 {
            compatible = "samsung,k8f1315ebm", "cfi-flash";
            reg = <2 0 0x4000000>;
        };
    };
};
有些细节需要各位注意：

    此machine仅有一个中断控制器：interrupt-controller@10140000
    标签"intc:"被加到了中断控制器的节点上，这个标签在父节点上创建了一个phandle，这个phandle就是父节点的interrupt-parent。所以这个中断控制器就成了系统所有子节点的默认中断控制器，只有当子节点明确的声明了其interrupt-parent才会被覆盖。
    每个设备使用interrupt属性来区分不同的中断输入线。
    #interrupt-cells（在interrupt-controller@10140000节点中）的值是2，所以，每个中断说明符由两个cell数据组成。这个例子中用的是最常见的 中断说明符 形式，第一个cell表示中断线的序号，第二个cell表示中断类型的flag（表示高有效，低有效。。。），对于不同的中断控制器，需要阅读对应的binding document来得知其 中断说明符 的格式。

#### 设备特定数据

在常用的属性之外，我们还能为一个节点自行添加属性及子节点。只要是系统需要的任何数据都能被我们按特定的规则来添加。
首先，新设备特定的属性名需要使用 厂商前缀，这样能避免与系统已有的标准属性名称冲突。
第二，每个属性都应该在某个binding文档中有相关的说明，这样驱动作者才能知道如何使用这些属性数据。
第三，将新的binding资料在devicetree-discuss@lists.ozlabs.org中post出来，大家对binding的代码审查将能规避大部分常识性错误。

特殊节点

##### aliases 节点

这个特殊节点用来引用一个长路径，比如/external-bus/ethernet@0,0，它是长路径的缩写或叫别名。比如：
    aliases {
        ethernet0 = &eth0;
        serial0 = &serial0;
    };
使用别名来标识一个设备是备受操作系统欢迎的做法。

##### chosen节点

chosen节点并不代表一个真正的设备，而是用来在Firmware与操作系统间传递数据，如启动参数。
通常chosen节点在dts中被置空。
在我们这个例子中，被添加了如下的启动参数：
 chosen {
        bootargs = "root=/dev/nfs rw nfsroot=192.168.1.1 console=ttyS0,115200";
    };



## 四、PCIe

### PCI Express（PCIe）

简称PCI-E，官方简称PCIe，是计算机总线PCI的一种，PCIe仅用与内部互联，PCIe拥有更快的速率，能够取代几乎所有的内部总线（PCI，AGP）。



### PCIe的地址住转换以及其上设备的中断映射

#### PCIe普通地址转换

类似于前面描述的local bus， PCI地址空间与CPU地址空间是完全分开的，所以需要地址转换才能从PCI地址获取到CPU地址。和之前一样，通过使用range，#address-cells, 和#size-cells属性来实现。

```
 pci@0x10180000 {  
    compatible = "arm,versatile-pci-hostbridge", "pci";  
    reg = <0x10180000 0x1000>;  
    interrupts = <8 0>;  
    bus-ranges = <0 0>;  

  
    #address-cells = <3>  
    #size-cells = <2>;  
    ranges = <0x42000000 0 0x80000000 0x80000000 0 0x20000000  
              0x02000000 0 0xa0000000 0xa0000000 0 0x10000000  
              0x01000000 0 0x00000000 0xb0000000 0 0x01000000>;  
}; 
```

PCI地址使用3个单元，三个单元被标记为phys.hi, phys.mid和phys.low[2]。（[2] 

PCI  Bus Bindings to Open Firmware.）

 

- phys.hi 单元: npt000ss bbbbbbbb dddddfff rrrrrrrr
- phys.mid 单元: hhhhhhhh hhhhhhhh hhhhhhhh hhhhhhhh
- phys.low 单元: llllllll llllllll llllllll llllllll

PCI地址是64位宽的，并被编码成phys.mid和phys.low 。其中phys.high中的比特由特殊含义：

- n：可重定位区域标志（在这里不起作用）（0，1）
- p：可预取（可缓存）区域标志（0，1）
- t：别名地址标志（在这里不起作用）（0，1）
- ss：空间代码（00，01，10，11）
- 00：配置空间
- 01：I/O空间
- 10：32位内存空间
- 11：64位内存空间
- bbbbbbbb: PCI总线编号,PCI结构是可分层的，所以我们可能有PCI/PCI桥，来定义子总线。
- ddddd:设备编号，通常与IDSEL信号连接相关联。
- fff:功能编号。用于多功能PCI设备
- rrrrrrrr: 寄存器编号；用于配置周期。

对于PCI地址转换，重要的字段是p和ss。 phys.hi中p和ss的值决定了访问的是哪个PCI地址空间。



因此，仔细观察ranges属性，我们有三个区域：

- 一个从PCI地址0x80000000处开始的512MByte大小的32位可预取内存区域，将被映射到host CPU的0x80000000地址处。
- 一个从PCI地址0xa0000000处开始的256MByte大小的32位非预取内存区域，将被映射到host CPU的0xa0000000地址处。
- 一个从PCI地址0x00000000处开始的16MByte大小的I/O区域，将被映射到host CPU的0xb0000000地址处。





#### PCIe-DMA地址转换

如果PCI-e支持DMA，还会有一个dma-range的属性。

#### 中断映射

现在我们来到了最有趣的部分，PCI中断映射。  PCI设备可以使用引线#INTA, #INTB, #INTC  和#INTD来触发中断。如果没有多功能PCI设备，那么设备就用#INTA实现中断。但PCI插槽或设备通常会连接到中断控制器的不同输入端。所以，device  tree需要一种将各种PCI中断信号映射到中断控制器输入端的方法。#interrupt-cells,  interrupt-map和interrupt-map-mask属性就被用于描述中断映射。

实际上，这里所描述的中断映射不仅限于PCI总线，任何节点都可以指定复杂的中断映射，但PCI是迄今为止最常见的。

```
 pci@0x10180000 {  
    compatible = "arm,versatile-pci-hostbridge", "pci";  
    reg = <0x10180000 0x1000>;  
    interrupts = <8 0>;  
    bus-ranges = <0 0>;  
  
    #address-cells = <3>  
    #size-cells = <2>;  
    ranges = <0x42000000 0 0x80000000  0x80000000  0 0x20000000  
              0x02000000 0 0xa0000000  0xa0000000  0 0x10000000  
              0x01000000 0 0x00000000  0xb0000000  0 0x01000000>;  
  
    #interrupt-cells = <1>;  
    interrupt-map-mask = <0xf800 0 0 7>;  
    interrupt-map = <0xc000 0 0 1 &intc  9 3 // 1st slot  
                     0xc000 0 0 2 &intc 10 3  
                     0xc000 0 0 3 &intc 11 3  
                     0xc000 0 0 4 &intc 12 3  
  
                     0xc800 0 0 1 &intc 10 3 // 2nd slot  
                     0xc800 0 0 2 &intc 11 3  
                     0xc800 0 0 3 &intc 12 3  
                     0xc800 0 0 4 &intc  9 3>;  
}; 
```

这是利用interrupt-map属性来实现的。中断映射的详细程序在[3]中有描述。因为中断号（#INTA等）不足以在单个PCI总线上区分若干PCI设备，我们也必须表明哪个PCI设备被中断线出发。幸运的是，每个PCI设备都有一个唯一的设备号。为了区分不同PCI设备的中断，我们需要一个包含PCI设备号和PCI中断号的元组。更一般来说，我们构造了一个有四个单元的单位中断说明符：3个#address-cells包括phys.hi,  phys.mid, phys.low，和一个#interrupt-cell (#INTA, #INTB, #INTC, #INTD)。

 

因为我们只设备号（部分PCI地址），interrupt-map-mask属性就发挥作用了。interrupt-map-mask属性也是一个四元组，如单位中断符。第一位表该单元中断符的一部分应该予以考虑。在我们的例子中，我们可以看到，只有phys.hi的唯一设备号部分是必须的，我们需要3位来区分4个中断线。（计数PCI中断线从1开始，而不是0  ！）

 

 

现在我们可以构建interrupt-map属性。该属性是一个表，表中的每个条目由一个子单位（PCI总线）中断符，一个父句柄（中断控制器负责提供中断服务）和父中断说明符。因此在第一行中，我们可以读取到PCI中断#INTA被映射到IRQ9，低电平敏感的中断控制器[4]。

现在唯一缺少的部分是奇怪的数字诠释了PCI总线的单位中断符。单位中断符的重要组成部分是phys.hi位域中的设备号。设备号是板子特有的，它取决于每个PCI主机控制器怎样激活每个设备上的IDSEL引脚。在本示例中，  PCI插槽1被分配了设备ID 24(0x18)，PCI插槽2被分配了设备ID  25(0x19)。每个槽的phys.hi值是由设备号偏移11位多达确定

 

插槽1的phys.hi是0xC000, 插槽2的phys.hi是0xC800.



全部放在一起interrupt-map属性显示为

- 主中断控制器上的插槽1的#INTA是IRQ9, 低电平敏感
- 主中断控制器上的插槽1的#INTB是IRQ10, 低电平敏感
- 主中断控制器上的插槽1的#INTC是IRQ11, 低电平敏感
- 主中断控制器上的插槽1的#INTD是IRQ12, 低电平敏感

- 主中断控制器上的插槽2的#INTA是IRQ10, 低电平敏感
- 主中断控制器上的插槽2的#INTB是IRQ11, 低电平敏感
- 主中断控制器上的插槽2的#INTC是IRQ12, 低电平敏感
- 主中断控制器上的插槽2的#INTD是IRQ9, 低电平敏感

interrupts = <8 0>; 属性描述了host/PCI-bridge控制器本身可能触发的中断。不要将这些中断与PCI设备可能会触发的中断(INTA, INTB, ...)混淆。

 

最后要注意一件事。就像interrupt-parent属性，节点上的interrupt-map属性是否存在将改变所有子节点和孙子节点的默认中断控制器。在本PCI例子中，这意味着PCI  host  bridge将成为默认中断控制器。如果通过PCI总线连接的设备直接连接到另一个中断控制器上，那它也需要指定它自己的interrupt-parent属性。











## Reference List

- [](https://blog.csdn.net/bob_fly1984/article/details/78078046)
- [Linux设备树用法](https://blog.csdn.net/green1900/article/details/41447755)
- [设备树的用法](https://blog.csdn.net/bob_fly1984/article/details/78078046)