# VIM环境搭建

## VIM插件简介

```
vim插件

AutoComplPop  

delview      

genutils  lookupfile          

 OmniCppComplete  tagbar         

vim-nerdtree-tabs  vim-surround

cscope_maps   

echofunc     

grep.vim  nerdtree             

vim-fugitive   vim-repeat

ctrlp.vim     

FuzzyFinder  L9        

nerdtree-git-plugin  

syntastic       

 vim-gitgutter  

vim-slime

```





## Git PLugin管理方式

1.

```

```

2.

```
vim ~/.vimrc

call plug#begin(‘～/.vim/plugged’)

Plug ''
PLug ''
Plug ''
...
...

call plug#end()



```



### Git Modules管理方式



```
1. git clone https://github.com/SilentAlice/.vim.git
2. cd .vim/bundle
3. git submodules update --init --recursive

```



#### vim

```
139 noremap <C-j> <C-w>j
140 noremap <C-k> <C-w>k
141 noremap <C-h> <C-w>h
142 noremap <C-l> <C-w>l


CTRL+  h/j/k/l   左/下/上/右  切换







```







```
F4：gerp查找
F5：在当前目录下查找
F6：

```

```

`+1,2,3,4....切换tmux窗口

`+c			创建tmux窗口
`+q			关闭tmux窗口






```



#### NERDTree

```
 " NERDTree
 nnoremap <silent><leader>t :NERDTreeTabsToggle<cr>                 
 
 " FufSearch                                                        
 nnoremap <silent><leader>f :FufFile<cr>                            
 "nnoremap <silent><leader>ft :FufTag<cr>                           
 
 " TagBar
 nnoremap <silent><leader>b :TagbarToggle<cr>                       
 
 " syntastic close location list
 nnoremap <silent><leader>l :lclose<cr>    
 
 
 
 \+t	打开NERDTree
 \+b	打开源文件的定义
 			包括macro、enum、struct、typedef....
 \+f	在当前目录下搜索文件
 
 
```

