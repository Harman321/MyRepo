# Cntlm配置代理



## 安装Cntlm

```
方式1：

wget 
tar 




方式2：
sudo apt-get install 

```



## 配置cntlm.conf文件

```
Username your_name	#是指的你访问代理服务器的用户名
Domain	 代理服务器的域
Proxy    代理服务器地址

Auth	NTLM		#验证方式，采用密文验证访问代理服务器账户的密码
PassLM	xxxxxxxx	#下个步骤会说明密文如何生成
PassNT	xxxxxxxx

Listen port		#port为自己配置的cntlm监听的端口，Cntlm会把这个端口转发到代理服务器
NoProxy	localhost, 127.0.0.*, 192.168.*

Gateway	yes
Allow 127.0.0.1	#允许谁可以使用使用这个代理
Deny 0/0
```

## 生成访问代理服务器账户的密钥

```
cntlm -c 自己编写的cntlm.conf文件 -H
会提示输入密码：这个密码指的是访问代理服务器的账户密码，cntlm和会把这个密码结合cntlm.conf文件中的Username生成密码的密文

输入密码之后会得到
Password：
PassLM	xxxxxxxx
PassNT	xxxxxxxx
PassNTLMv2	xxxxxxxx  #Only for user '',domain ''

若cntlm.conf文件中配置的Auth NTLM
把生成的
PassLM	xxxxxxxx
PassNT	xxxxxxxx
拷贝到cntlm.conf文件
```



## 启动Cntlm服务

```
cntlm -c 自己编写的cntlm.conf文件
```

## 在~/.bashrc 添加

```
export http_proxy="http://127.0.0.1:port"
export https_proxy="https://127.0.0.1:port"

source ~/.bashrc
```

## 测试代理是否成功

```
cntlm -c 自己编写的cntlm.conf文件 -I -M http://www.baidu.com
或者直接
wget http://www.baidu.com
```

