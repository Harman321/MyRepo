Virtulization

Virtulization：

- 在移动或嵌入式领域，使得多个OS（RTOS，SecureOS，RichOS）能共享底层hardware，充分利用硬件资源，降低了BOM（Bill Of Materials：物料清单）成本。

- 有助于解决安全问题，有助于实现隔离

  例如在汽车子系统中，Virtulization能够实现各驱动之间的隔离，使得非关键驱动（娱乐单元等）的故障不会影响到关键驱动（制动系统驱动等）

- 有助于提高软件的可移植性，降低软件开发成本。

VMM（Virtual Machine Monitor）或者Hypervisor放在OS和hardware之间，每个Guest OS运行在自己的虚拟机中（VM：Virtual Machine），所有的虚拟机由VMM管理。Guest OS使用的都是虚拟地址VA，需要先转换为中间物理地址IPA，然后再转换为真正的物理地址PA，这样任何Guest OS在逻辑上都好像使用了整个hardware平台。



### Hypervisor/VMM

Hypervisor是在OS和hardware之间的软件层，使得多个OS能够共享一套hardware，因此Hypervisor有时也叫“元操作系统”。Hypervisor能够协调OS来访问物理硬件，因此Hypervisor也叫做VMM（Vitual Machine Monitor）：虚拟机监视器。





## Hypervisor/VMM的分类

### 分类方法1：

#### Type1 Hypervisor

VMM直接安装造Hardware和OSs之间

优点：

对下虚拟机不依赖于具体的操作系统

对上可支持多种类型的操作系统

缺点：



代表性产品:

VMware ESxServer

![](pic/virtualization/type1.png)

#### Type2 Hypervisor



优点：



缺点：



代表性产品:





![](pic/virtualization/type2.png)



#### 混合架构

优点：



对上可支持多种操作系统

缺点：

需要硬件支持虚拟化扩展功能

代表性产品:

KVM



### 分类方法2：

#### 全虚拟化：Full Virtualization

特点：

Hypervisor/VMM层用于协调Guest OSs访问底层的hardware。



优点：

Guest OS能够在不经修改的情况下跑在VMM上

性能很好

缺点：



代表性产品：

Oracle的VIrtual Box

VMware Worktation和VMware Sphere

**Red Hat的KVM**



应用场景：



#### 半虚拟化：Para Virtualization

特点：



优点：

性能接近物理机



缺点：

需要Guest OS的代码级支持，



代表性产品：

** Citrix的Xen**

应用场景：

Cloud





















## 几个虚拟化产品简介：



### KVM：Red Hat

KVM（Kernel-based Virtual Machine）



- KVM是Linux Kernel中的一个模块，它利用Linux自身的任务调度、内存管理与硬件设备交互。要使用KVM实现虚拟化技术，有了KVM模块，还需要一个用户空间的工具来操作这个KVM模块，比如创建一个虚拟机。KVM选择QEMU来作为这个用户空间的工具。

- KVM 需要芯片支持虚拟化技术（英特尔的 VT 扩展或者 AMD 的 AMD-V 扩展）。

- **在KVM中，可以运行各种不需要更改的GNU/Linux, Windows 或任何其他系统镜像**。









### XEN：Citrix



是一种半虚拟化解决方案，**需要修改Guest OS的内和源码**



### VMware：VMware



### Hyper-V：Microsoft

基于Xen的修改版本









## QEMU


QEMU：是一个广泛使用的开源“计算机仿真器”和“虚拟机"



- 当作为仿真器时，可以在一种架构(如PC机)下运行另一种架构(如ARM)下的操作系统和程序。通过动态转化，可以获得很高的运行效率。比如说在x86的CPU上可虚拟一个Power的CPU，并可利用它编译出可运行在Power上的程序。 

- 当 QEME 作为虚拟机时，可以使用 [xen](https://wiki.archlinux.org/index.php/Xen_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)) 或 [kvm](https://wiki.archlinux.org/index.php/KVM_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)) 访问 CPU 的扩展功能([HVM](https://en.wikipedia.org/wiki/Hardware-assisted_virtualization))，在主机 CPU 上直接执行虚拟客户端的代码，获得接近于真机的性能表现

### QEMU、KVM、XEN的关系

Qemu是一套独立的虚拟化解决方案，KVM是另一套虚拟化解决方案，不过因为这个方案实际上只实现了内核中对处理器(Intel VT,  AMDSVM)虚拟化特性的支持，换言之，它缺乏设备虚拟化以及相应的"用户空间管理虚拟机的工具"，所以它借用了QEMU的代码并加以精简，连同KVM一起构成了另一个独立的虚拟化解决方案，不妨称之为：KVM+QEMU.。

Xen是另一套独立的虚拟化解决方案，最初的Xen只支持半虚拟化，Intel VT技术出现后，添加了全虚拟化功能，这个全虚拟化功能也是借助了qemu实现，但不是完全依赖qemu。  



## Reference Lists

[ [1] QEMU](https://wiki.archlinux.org/index.php/QEMU)

[ [2] Xen、KVM、Qemu间的关系和区别](https://blog.csdn.net/ysbj123/article/details/51166343)