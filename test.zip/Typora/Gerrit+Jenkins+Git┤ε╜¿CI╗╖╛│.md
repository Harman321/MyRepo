# Gerrit+Jenkins+Apache2搭建CI环境

[TOC]



## CI持续集成环境的必要性

### CI工作大致过程

用户git review提交代码---->提交到Gerrit库---->触发Jenkins自动构建、执行测试脚本---->测试通过,为Gerrit仓库打Verified标签---->Gerrit上人工审核review，review通过---->Gerrti执行Replication---->push GIt remote





## 工具介绍

### Gerrit：代码Review工具

Gerrit是一种开放源代码的代码审查软件，使用网页界面，利用网页浏览器，同一团队的程序员能够相互审阅彼此修改后的代码，决定是否能够提交、退回或者继续修改。它利用版本控制系统Git作为底层。

Gerrit用Java和SQL实现，使用Google Web Toolkit产生前端的JavaScript

Gerrit著名用户：

- Android

- Go
- OpenStack
- Eclipse Foundation|Eclipse基金会
- LibreOffice

### Jenkins

Java编写的开源持续集成工具，广泛应用于项目开发，能够自动化构建、测试和部署。可以通过各种手段触发构建，例如提交代码给版本控制系统时触发。Jenkins可以生成各种格式的测试报告，如报表，趋势图，并在图形界面中呈现他们。





## CI持续构建环境搭建过程

### 环境搭建的准备

Gerrit和Jenkins都是运行在Java环境下，Gerrit还需要数据库的支持，因此需要安装JDK，数据库在这里我们选用mysql

#### 安装JDK

##### 方法1：apt-get方式

安装：

```
apt-get install openjdk-8-jre-headless
```

验证：

```
java -version验证是否安装成功
```

##### 方法2：手动安装

下载

```
wget --no-cookies --no-check-certificate --header "Cookie: gpw_e24=http%3A%2F%2Fwww.oracle.com%2F; oraclelicense=accept-securebackup-cookie" "http://download.oracle.com/otn-pub/java/jdk/8u141-b15/336fa29ff2bb4ef291e347e091f7f4a7/jdk-8u141-linux-x64.tar.gz"
```

解压

```
tar xzf jdk-8u141-linux-x64.tar.gz
```

配置环境变量

export JAVA_HOME="/xx/xx/jdk1.8.0_171:$JAVA_HOME"

export PATH="$JAVA_HOME/bin:$PATH"

export CLASSPATH=".:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar"



#### 安装Git

安装

```
sudo apt-get install git
```

验证

```
git --version
```



### 安装Apache2

#### 方法1：apt-get方式

安装

```
sudo apt-get install apache2 
```

Apach开启反向代理

```
sudo a2enmod proxy
sudo a2enmod proxy_ajp
sudo a2enmod proxy_balancer
sudo a2enmod proxy_connect
sudo a2enmod proxy_ftp
sudo a2enmod proxy_http
后面Gerrit和Jenkins都会用得到
```

修改/etc/apche2/httpd.conf	

```
添加配置   “ServerName localhost”
```

添加虚拟主机配置文件    
    sudo vi /etc/apache2/gerrit-httpd.conf

    <VirtualHost *:8090>
            ServerName localhost
    		ProxyRequests Off
            ProxyVia Off
    		ProxyPreserveHost On
    
            <Proxy *>
    				Order deny,allow
    				Allow from all
            </Proxy>
    		
    		<Location "/login/">
                    AuthType Basic
                    AuthName "Gerrit Code Review"
                    Require valid-user
    				AuthBasicProvider file
    				AuthUserFile /home/gerrit/document/passwords
    		</Location>
    		
    		AllowEncodedSlashes On
    		ProxyPass / http://localhost:8080/
    
    </VirtualHost>


	注：如httpd.conf没有Include到apache2.conf中，需手动添加：
	sudo vi /etc/apache2/apache2.conf
	添加:  Include gerrit-httpd.conf
	
	修改配置文件，添加对8081端口的监听：
	sudo vi /etc/apache2/ports.conf
	                
	添加:  Listen 8081
		  Listen 8090
启动apache2

```
sudo /etc/init.d/apache2 start
```

#### 方法2：手动安装

```
下载apr（安装httpd需要）
http://apr.apache.org/

下载apr-util（安装httpd需要）
http://apr.apache.org/

下载pcre
http://www.pcre.org/

下载httpd(本文用的httpd-2.4.33.tar.bz2 )
http://httpd.apache.org/

```

安装apr

```

解压（解压路径自己设定）
cd /usr/local/src/apache
tar zxvf  apr-1.5.1.tar.gz
cd apr-1.5.12
配置./configure --prefix=/usr/local/apr
编译make
安装make install
```

安装apr-util

```
解压（解压路径自己设定）
cd /usr/local/src/apache
tar zxvf apr-util-1.5.3.tar.gz
cd apr-util-1.5.3
配置
./configure --prefix=/usr/local/apr-util --with-apr=/usr/local/apr/bin/apr-1-config
编译make
安装make install
```

安装apache2

```
解压
cd /usr/local/src/apache
tar -zvxf httpd-2.4.tar.gz
cd httpd-2.4.9
编译
mkdir -p /usr/local/apache2
./configure --prefix=/usr/local/apache2 --with-apr=/usr/local/apr --with-apr-util=/usr/local/apr-util --with-ssl --enable-ssl --enable-module=so --enable-rewrite --enable-cgid --enable-cgi --enable-proxy_ajp --enable-proxy_balancer --enable-proxy_connect --enable-proxy_ftp --enable-proxy_http

--prefix=/usr/local/apache2 ：apache2的安装路径
 --with-apr=/usr/local/apr：依赖的apr的位置
 --with-apr-util=/usr/local/apr-util：依赖的apr-util的位置
 --enable-rewrite ：支持url重写
 --enable-proxy_ajp：
 --enable-proxy_balancer：
 --enable-proxy_connect：
 --enable-proxy_ftp：
 --enable-proxy_http：
 --enable-modules=most:指明要静态编译进httpd二进制文件的模块，most包含大部分重用模块，也可以设置为all，或者是一个modules list
  --enable-ssl：支持ssl
  --with-ssl=/xx/xx/openssl：指定ssl的安装位置
 
编译make
安装make install
```

配置Apache

```
1.配置conf/extra/httpd-vhosts.cof

<VirtualHost *:8090>	//表示Apache反响代理的端口
        ServerName localhost
		ProxyRequests Off
        ProxyVia Off
		ProxyPreserveHost On

        <Proxy *>
				Order deny,allow
				Allow from all
        </Proxy>
		
		<Location "/login/">
                AuthType Basic
                AuthName "Gerrit Code Review"
                Require valid-user
				AuthBasicProvider file
				AuthUserFile /home/xx/document/passwords //使用htpasswd生成gerrit账户时会用到
		</Location>
		
		AllowEncodedSlashes On
		ProxyPass / http://localhost:8081/
		ProxyPassReverse / http://localhost:8081/
</VirtualHost>


2. 配置conf/httpd.conf

添加监听
Listen 8090
ServerName 127.0.0.1

去掉#LoadModule vhost_alias_module modules/mod_vhost_aliase.so前的#
去掉#Include extra/http-vhosts.conf前的#
根据需要去掉#，以便使能相应的module


```

启动apache2

```
apahce启动命令：
推荐/usr/local/apache2/bin/apachectl start apaceh启动

apache停止命令
/usr/local/apache2/bin/apachectl stop   停止

apache重新启动命令：
/usr/local/apache2/bin/apachectl restart 重启
```



### 安装Apache+Gerrit

#### 安装Mysql

这里我们在Gerrit需要用到Mysql，所以先对Mysql进行安装

##### 方法1：apt-get方式

下载：

```
https://dev.mysql.com/downloads/mysql/
```

安装：

```
sudo apt-get install mysql-server
```

验证：

```
systemctl status mysql.service 可以查看状态，默认为开启状态。如果未开启，可使用 sudo systemctl start mysql来开启
```

为Gerrit配置mysql数据库,切换mysql账户

```
mysql -u root -p
```

创建mysql数据库用户gerrit

```
create User 'gerrit'@‘localhost’ identified by ”123456“；
此处创建的gerrit仅允许本地访问，如果向创建允许外网IP访问，可以通过
create user 'gerrit'@'localhost' identified by '123456'; 创建
```

创建gerrit使用的database  gerritdb

```
create database gerritdb  charset=Latin1
```

授予权限：授予用户在本地服务器对该数据库的全部权限

```
grant all on gerritdb.* to 'gerrit'@'localhost'   
```

刷新权限

```
flush privileges
```

用新帐号 gerrit 重新登录

```
mysql -u gerrit  -p  
```

##### 方法2：手动安装

下载：

```
https://dev.mysql.com/downloads/mysql/
```

解压：

```
tar -zxvf mysql-5.7.20-linux-glibc2.12-x86_64.tar.gz
mv mysql-5.7.20-linux-glibc2.12-x86_64 ../mysql-5.712
```

安装mysql服务：

```
./bin/mysqld --user=安装mysql的账户xx  --basedir=/home/xx/mysql-5.7/  --datadir=/home/xx/mysql-5.7/data/   --initialize  --explicit_defaults_for_timestamp=1
```

记住生成的随机密码，第一次登录时需要（红色的就是随机生成的密码） 

新建**mysql.conf**文件，配置如下

```
[mysqld]
basedir=/home/xx/mysql-5.7
datadir=/home/xx/mysql-5.7/data
port=3306
character-set-server=utf8
```

在bin目录下，启动mysql服务：

```
./mysqld --defaults-file=/home/xx/mysql-5.7/mysql.conf
```

在bin目录下，开启客户端：

```
./mysql --defaults-file=/home/xx/mysql-5.7/mysql.conf -u xx -p  //用账户xx登陆mysql
```

第一次登录后会立刻要求修改密码

```
alter user 'root'@'localhost' identified by '123456';
```

创建mysql数据库用户gerrit

```
create User 'gerrit'@‘localhost’ identified by ”123456“；
此处创建的gerrit仅允许本地访问，如果向创建允许外网IP访问，可以通过
create user 'gerrit'@'%' identified by '123456'; 创建
```

创建gerrit使用的database  gerritdb

```
create database gerritdb  charset=Latin1
```

授予权限：授予用户在本地服务器对该数据库的全部权限

```
grant all on gerritdb.* to 'gerrit'@'localhost'   
```

刷新权限

```
flush privileges
```

用新帐号 gerrit 重新登录

```
mysql -u gerrit  -p  
```

#### 安装Gerrit

下载

```
下载下面三个包
mysql-connector-java-5.1.21.jar
bcpkix-jdk15on-1.52.jar（可以不用）
gerrit-2.5.4.war
```

安装Gerrit

```
mkdir gerrit_site
java -jar gerrit-2.5.4.war init -d gerrit_site   //-d指定安装路径
安装过程中需要更改的选项（其他采用默认选项）：
	DataBase Server：mysql
	database name：填写安装mysql时为gerrit创建的数据库gerritdb
	Authenticatin method此处使用Apache作为外部鉴权，直接选择http
	Email Deliver:可以根据需要配置自己的邮箱
	Install Verified label [y/N]? y
	
```

更新配置文件：

```
sudo vim gerrit_site/etc/gerrit.config

[gerrit]
        basePath = git  //#默认gerrit对应的git库
        canonicalWebUrl = http://localhost:8090/    //代理服务器的地址
        useSSL = false	//在这里没有用到ssl
[database]
        type = mysql
        hostname = localhost
        database = gerritdb
        username = gerrit
[auth]
        type = HTTP    //#auth模式，默认为OPENID，配置为HTTP，需要apache配置反向代理
[receive]
        enableSignedPush = false
[sendemail]
        smtpServer = localhost  
[container]
        user = gerrit
        javaHome = /usr/lib/jvm/java-8-openjdk-amd64/jre
[sshd]
        listenAddress = *:29418
[httpd]
        listenUrl = proxy-http://*:8081/
[cache]
        directory = cache
[index]
        type = LUCENE

```

启动Gerrit服务

	gerrit_site/bin/gerrit.sh  start
创建Gerrit用户

```
#touch gerrit/documents/passwords
#htpasswd -cb /home/gerrit/documents/passwords admin admin
#htpasswd -c /home/gerrit/documents/passwords  user1 user1 //第二次创建用户时只用-c参数

此密码文件对应Apache的配置文件中的AuthUserFile选项配置的密码文件
```



### 安装Tomcat+Jenkins

#### 方法1：apt-get方式

安装

```
wget -q -O - http://pkg.jenkins-ci.org/debian/jenkins-ci.org.key | sudo apt-key add - 

sudo sh -c 'echo deb http://pkg.jenkins-ci.org/debian binary/ > /etc/apt/sources.list.d/jenkins.list'  

sudo apt-get update -y  

sudo apt-get install jenkins -y 

安装目录：/var/lib/jenkins  
日志目：/var/log/jenkins/jenkins.log  
安装时会默认创建一个jenkins账户，默认家目录为/var/lib/jenkins。
也可以更改

更改jenkins目录（没有尝试）
 chown -R jenkins:jenkins /home/luchang/jenkins
 
sudo vi /etc/profile 中添加 export JENKINS_HOME=/home/luchang/jenkins
sudo service jenkins restart 
```

启动和停止

```
sudo /etc/init.d/jenkins start  

sudo /etc/init.d/jenkins stop
```

测试

```
http://localhost:8080
```

#### 方法2：手动安装

##### 安装tomcat

下载，解压

启动:bin/startup.sh

关闭:bin/shutdown.sh



##### 安装Jenkins

下载jenkins的war包，放在Tomcat的webapps下

启动Tomcat

验证：

https://localhost:8080









## 常见问题解决方案：

### Jenkins相关

#### 安装Jenkins之后，可选插件列表为空

选择插件管理-高级-升级站点-更改URL为  `[http://mirror.xmission.com/jenkins/updates/update-center.json]`-点击提交即可



### Jenkins管理Credentials







## Reference Lists

[ [1] Apache配置优化](http://blog.51cto.com/taoliang/1914375)

[ [2] Apache安装与配置](https://blog.csdn.net/CleverCode/article/details/45438495)

[ [3]CI持续集成环境](http://www.cnblogs.com/kevingrace/p/5651447.html)
