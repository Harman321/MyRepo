# CI持续集成环境搭建

# 	         ——Gerrit+Jenkins+CodeCLub对接篇



## Overview



### CI涉及的角色

Gerrit的用户：管理员账户admin，普通用户jenkins（用于与Jenkins对接）

Jenkins的用户：管理员账户admin

CodeClue的普通开发者账户：



## Gerrit与Codeclub的对接

### CodeClub配置

#### 1.创建一个新项目 test-project1



#### 2.在项目中添加.gitreview文件

前面我们在Gitlab上搭建了一个 test-project1 的工程，普通用户是没有办法去 push 的，只能使用 git review 命令提交. 而 git review 命令需要 .gitreview 文件存在于项目目录里。 用 gerrit用户添加.gitreview 文件

```
[gerrit]
host=103.10.86.30
port=29418
project=test-project1.git

注：
1.  .gitreview文件需要与～/.ssh/config文件共同作用，注意两者配置的协调
2.  .gitreview能够使普通开发者，git review的时候根据文件配置的Gerrit服务器，把代码提交到Gerrit服务	   器上，从而触发Jenkins对项目进行构建、测试，然后为项目打上Verify标签。项目管理员登陆Gerrit，并对代     码进行Code-Review+2,然后cherry pick，最后才merge


```

### Gerrit配置

#### 1. public key的设置

```
2. jenkins登陆Gerrit，将Gerrit的使用着账户jenkins的public key添加到Gerrit中

注：
配置完public key之后可以利用命令验证是否成功
ssh -p 29418  user2@172.16.206.133
29418为gerrit上SSH服务器监听的端口，user2为登录的gerrit账号，注意这里我们使用哪个账号登录gerrit就使用哪个账号测试，并且该账号已经登录了gerrit服务器，而且公钥已经上传。172.16.206.133为gerrit服务器的IP
```

#### 2.Gerrit端设置Stream Events 

设置Stream Events目的是为了与Jenkins对接

管理员admin登录gerrit 
Projects->List->All-Projects Projects->Access Global Capabilities->Stream Events 点击 Non-Interactive Users 添加 Jenkins 用户到 ‘Non-Interactive Users’ 组。

![](pic/CI/capability1.png)

添加用户时，可以只指定账户：jenkins，也可以只指定邮箱

![](pic/CI/capability2.png)

#### 3.Gerrit创建项目与CodeClub上的 项目关联

Gerrit上设置 test-project1工程 在Gerrit上创建 test-project1 项目 要知道review是在gerrit上，而gerrit上现在是没有项目的，想让gitlab上的项目能在gerrit上review的话，必须在gerrit上创建相同的项目，并有相同的仓库文件. 

```
gerrit上的项目最好是从gitlab上git clone --bare过来，并且项目不要为空

cd /home/gerrit/gerrit_site/git/            //即登陆到gerrit安装目录的git下
git clone --bare git@xxx:dev-group/test-project1.git             //创建并将远程gitlab上的这个项目内容发布到gerrit上

同步 Gerrit的test-project1 项目到 Gitlab 上的 test-project1 项目目录中
当用户git review后，代码通过 jenkins 测试、人工 review 后，代码只是 merge 到了 Gerrit 的 test-project1 项目中，并没有 merge 到 Gitlab 的 test-project1 项目中，所以需要当 Gerrit test-project1 项目仓库有变化时自动同步到 Gitlab 的 test-project1 项目仓库中。
```

#### 4.配置Gerrit merge之后自动同步到CodeClub

Gerrit 自带一个 Replication 功能，同时我们在安装 Gerrit 时候默认安装了这个 Plugin。

如果没有安装Replication插件，可以先通过下面的方式安装

```
手动安装gerrit插件

cd /home/gerrit
[gerrit@115r ~]$ ls
gerrit-2.11.3.war gerrit_site

进行插件安装，下面安装了四个插件
java -jar gerrit-2.11.3.war init -d gerrit_site --batch --install-plugin replication
java -jar gerrit-2.11.3.war init -d gerrit_site --batch --install-plugin reviewnotes
java -jar gerrit-2.11.3.war init -d gerrit_site --batch --install-plugin commit-message-length-validator
java -jar gerrit-2.11.3.war init -d gerrit_site --batch --install-plugin download-commands

查看plugins目录，发现已经有插件了
[gerrit@115r ~]$ cd gerrit_site/plugins/
[gerrit@115r ~]$ ls
commit-message-length-validator.jar download-commands.jar replication.jar reviewnotes.jar
```

安装Replication插件之后

```
现在只需要添加一个 replication.config 给 Gerrit

cd /home/gerrit/gerrit_site/etc/
vim replication.config

replication.config
	[remote ]
	projects = project_name
	url = git@xxx:xx/project_name	//可以直接从代码托管平台获得
	push = +refs/heads/*:refs/heads/*
    push = +refs/tags/*:refs/tags/*
    push = +refs/changes/*:refs/changes/*
    threads = 3

设置gerrit用户的 ~/.ssh/config

host	xxx
	#user
	hostname	xxx
	identituFile	~/.ssh/id_rsa
	StrictHostKeyChecking no		//
    UserKnownHostsFile /dev/null	//
    

```



## Gerrit与Jenkins的对接



### 设置Gerrit Trigger

1. 建立一个能够与Gerrit对接的服务器

![](/home/kabu-nuo/下载/trigger1.png)



![](/home/kabu-nuo/下载/trigger2.png)

**建立Jenkins与Gerrit对接的信息**

在Jenkins中配置Gerrit信息，包括Gerrit的Hostname，Gerrit的URL，Gerrit的SSH端口，以及Gerrit的登陆账户，账户邮箱，使用的public key。配置完成之后点击Test Connection

![](/home/kabu-nuo/下载/trigger3.png)

如果能够Success，将会看到下面的效果

![](/home/kabu-nuo/下载/trigger4.png)



### Gerrit与Jenkins对接

让Gerrit支持Jenkins 如果安装Gerrit时没有或者没有选择添加Verified标签功能[‘lable Verified’]，需要自己添加。

```
用gerrit管理员账号登录Gerrit 现在提交的Review请求只有Code Rivew审核，我们要求的是需要Jenkins的Verified和Code Review双重保障，

在 Projects 的 Access  栏里，针对 Reference: refs/heads/ 项添加 Verified 功能，如下： Projects -> List -> All-Projects Projects -> Access -> Edit -> 找到 Reference: refs/heads/* 项 -> Add  Permission -> Label Verified -> Group Name 里输入 Non-Interactive  Users -> 回车 或者 点击Add 按钮 -> 在最下面点击 Save Changes 保存更改。
```



### Jenkins上创建项目 添加 test-project1工程

![](pic/CI/jenins1.png)

![](pic/CI/jenkins2.png)

下面添加url：http://xxx:8080/p/test-project1.git 添加分支：origin/$GERRIT_BRANCH

![](pic/CI/jenkins3.png)

然后点击Add Branch--->添加一个Branch Sperifier（blank for ’any‘）：内容为：    */master



构建触发器

![](pic/CI/jenkins4.png)



![](pic/CI/jenkins5.png)

结果：

![](pic/CI/jenkins6.png)

### Jenkins上设置执行的测试脚本

在Jenkins上创建项目test-project1时配置构建的脚本

![](pic/CI/shell.png)

Command可以是一个简单的ls命令（作为测试使用）

















## 常见错误：

1. **Gerrit利用replication将代码同步到CodeClub时：Git push error pre-receive hook declined**

原因:GitLab、CodeClub或者其他代码托管平台创建的项目默认是protected的，master是受保护的，所以直接利用Gerrit replcation到Codelub的master分支是不允许的。

GitLab by default marks `master` branch as `protected` (See part `Protecting your code` in <https://about.gitlab.com/2014/11/26/keeping-your-code-protected/> why). If so in your case, then this can help:

> Open your project > Settings [> Repository tab] and go to  "Protected branches", select: "Developers can push" and try again.

参考链接： [Git push error pre-receive hook declined](https://stackoverflow.com/questions/28318599/git-push-error-pre-receive-hook-declined)

2. **Gerrit利用replication将代码同步到CodeClub时：出现rejected hostkey**

```
原因：～/.ssh/config或者replcation.config配置有误

～/.ssh/config

host	xxx
	#user
	hostname	xxx
	identituFile	~/.ssh/id_rsa
	StrictHostKeyChecking no		//
    UserKnownHostsFile /dev/null	//
	
replication.config
	[remote ]
	projects = project_name
	url = git@xxx:xx/project_name	//可以直接从代码托管平台获得
	push = +refs/heads/*:refs/heads/*
    push = +refs/tags/*:refs/tags/*
    push = +refs/changes/*:refs/changes/*
    threads = 3
```

3. **Gerrit中submit代码时：出现Submit including parents**![](pic/CI/2.png)

   需要gerrit.config中配置

   [submit]

   ​	action = cherry out

   ​	mergeContent = true

![](pic/CI/1.png)



4. **Couldn't find any revision to build . Verify  the respository  and branch configuration for this job**

   参见小节：Jenkins上创建项目 添加 test-project1工程



5. **Gerrit管理多个项目**

   **多个工程的replication** ，可配置replication为

   ```
   [remote "test-project1"]
   projects = test-project1
   url = git@xxx:dev-group/test-project1.git
   push = +refs/heads/*:refs/heads/*
   push = +refs/tags/*:refs/tags/*
   push = +refs/changes/*:refs/changes/*
   threads = 3
    
   [remote "xqsj_android"]
   projects = xqsj_android
   url = git@xxx:app/xqsj_android.git
   push = +refs/heads/*:refs/heads/*
   push = +refs/tags/*:refs/tags/*
   push = +refs/changes/*:refs/changes/*
   threads = 3
   ```

   6. **git commit缺少Change-Id**

      临时解决git commit -m ""  --amend

      永久解决：利用commit-msg脚本

​	参考：https://blog.csdn.net/yanxiangyfg/artical/details/50962593

​		   https://blog.csdn.net/liuxu0703/artical/details/54343096

​		   

## References List



[ [1] CI持续集成环境构建](http://www.cnblogs.com/kevingrace/p/5651447.html)

[ [2] Submit patch in gerrit without parents](https://stackoverflow.com/questions/43231417/submit-patch-in-gerrit-without-parents)

[ [3] Gerrit Missing Change-Id]( https://blog.csdn.net/liuxu0703/artical/details/54343096)