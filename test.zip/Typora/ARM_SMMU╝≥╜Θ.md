# ARM SMMU

## SMMU概述

### 引入SMMU的动机：

##### 1. 隔离和安全的角度:

隔离“共享相同物理存储介质”的外设（DMA Devices）。

一般的外设（peripheral devices）是CPU拥有的，外设要读写物理内存，需要中断CPU。

但是拥有DMA硬件的外设能够直接访问物理内存，为了隔离DMA设备访问的物理内存，引入SMMU

##### 2. 虚拟化的角度

VMM（Virtual Machine Monitor）或者Hypervisor放在OS和hardware之间，每个Guest OS运行在自己的虚拟机中（VM：Virtual Machine），所有的虚拟机由VMM管理。Guest OS使用的都是虚拟地址VA，需要先转换为中间物理地址IPA，然后再转换为真正的物理地址PA，这样任何Guest OS在逻辑上都好像使用了整个hardware平台。

##### 3.扩展地址：

让地址总线不足的设备能够访问系统整个的内存空间。例如可以让一个32位设备访问64位系统中的所有内存空间。MU Translation

SMMU的Stage2的目的是benefit VMM（Virtual Machine Monitor）：

增加SMMU的Stage2 address translation，能够把hypervisor中完全用软件来管理shadow translation table的过程转换为SMMU硬件管理，能够得到一个更好的性能。


有了SMMU的Stage2，任何Gu

### SMMU是什么，作用是什么？

![](pic/mmu/introduction.png)

1. SMMU是针对DMA设备而设计的一个硬件
2. SMMU在DMA设备请求system IO这个path中进行地址翻译，而system-->DMA设备这个path的地址翻译由其他组件负责（例如CPU中的MMU）
3. 引入SMMU的目的是为了隔离性和安全性



### SMMU在一个系统中的位置？

一个系统中可能会存在若干个SMMU，一个SMMU可能只针对一个DMA设备进行地址翻译，也可能针对一组DMA设备进行地址翻译

![](pic/mmu/position1.png)

#### SMMU的实现方式

SMMU在一个系统中具体的实现形式

- SMMU可以集成到某些DMA设备的内部
- SMMU可以同时为多个DMA Device提供Address Translation操作
- SMMU也可以采用分布式的实现方式

![](pic/mmu/position.png)

### SMMU的2个Stage简介

SMMU支持两个Stage对VA进行翻译。两个Stage可以分别单独地被enable，也可以一起被enable。Stage1主要是为了提供隔离机制，Stage2主要是为了支持Virtualization Extension，以及虚拟化物理设备到到虚拟机中的地址空间，也即使得所有虚拟机中的Guest OS共享系统中的DMA设备。

#### Stage1 Of SMMU Translation

主要目的是协助Operating System（无论这个OS运行在本地还是虚拟机中：即无论运行在虚拟系统与否），下图是SMMU Stage1的过程，类似于CPU 中MMU硬件的地址翻译过程。

![](pic/mmu/stage1.png)

既然SMMU的Stage1和CPU中的MMU具有类似的地址翻译过程，为什么不直接采用MMU技术？原因很简单：SMMU是针对DMA设备的，而DMA设备访问物理内存是不经过CPU的MMU的。

使用SMMU还能带来以下好处：

1. Fragmentation of physical memory：碎片化的物理内存

   对于物理内存，无论OS kernel还是上层的Application会经常的alloc and free，最终造成物理内存的碎片化，这种碎片化程度在多个Guest OS共享同一份物理内存的时候更加严重。但是一些设备本质上是需要一块连续的物理内存才能够高效的工作（例如：digital camera需要连续的内存来快速地存储高清照片，手机播放高清vedio时，需要一块连续的物理内存来decode vedio）。

   当这些需要大块连续物理内存的device或者DMA device需要在碎片化的物理内存（fragmented physical memory）上运行时，为了提高他们的性能，典型的做法有：

   （1）采用软件技术：例如DMA Scatter-Gather，但是这种方法的复杂性高，存在性能瓶颈（performance overheads）。（2）通过引入SMMU解决，SMMU Stage1进一步进行地址转换（address translation），将“物理内存中的内存碎片”（小至4K）被虚拟地gathered，然后在虚拟地址空间层面对外暴露为连续的blocks（在没有虚拟化的系统中），或者将“中间物理内存中的内存碎片”（小至4K）被虚拟的收集起来，然后在虚拟地址空间对外暴露为连续的blocks（在有虚拟化的系统中）。

2. Device可寻址范围受限问题

   另一个主要的issue是：为了兼容老系统，在新系统中一些device不能访问所有的内存范围。例如，16或24位设备无法访问32位体系结构中的所有内存，32位的设备无法访问64位体系结构中所有的内存。传统的解决方案是：在低地址空间区域开辟一个imtermadiate aera（或者称为bounce buffering：跳转缓冲区），这个区域作为一个bridge，例如一个DMA设备的目的地址在16M以上，但一些老的设备只能访问16M以下的内存，这时候就需要在设备能访问的16M范围内设置一个buffer作为跳转，这种额外的数据拷贝称为“bounce buffering”。

   对策：SMMU能够避免“bounce buffering”问题。SMMU的Stage1能够使DMA Agent访问any address in the system，而不用受限于DMA agent的bus width

![](pic/mmu/smmu.png)



#### Stage2 Of SMMU Translation

SMMU的Stage2的目的是benefit VMM（Virtual Machine Monitor）：

增加SMMU的Stage2 address translation，能够把hypervisor中完全用软件来管理shadow translation table的过程转换为SMMU硬件管理，能够得到一个更好的性能。



有了SMMU的Stage2，任何Guest OS可以直接在IPA层面对任何DMA device进行配置，使得DMA device和Guest OS能够共享相同的address space



同样，有了SMMU的Stage2，可以把SMMU配置为：一个Guest OS的设备操作不会破坏另一个Guest OS的内存

![](pic/mmu/stage2.png)

这种分阶段（Gutse:Stage1和VMM:Stage2）的地址转换，也为地址翻译错误在适当的Stage进行处理

### SMMU工作原理

Address  Translate过程大致如Figute 6：	

CD（Context DIscrpitor）关联着（1）Stage1（VA-->IPA） Translate Table的基地址指针；（2）每个StreamID的Confiruration；（3）ASID。Translate过程如果需要Stage2，STE同时包含着（4）Stage2（IPA-->PA）Translation Table的基地址指针；（5）VMID。

![](pic/mmu/example_cd.png)





### SMMUv3.0的特点

SMMUv3.0支持PCI Express Root Comples以及potential large IO systems

- Memory-based configuration structures to support large numbers of streams.

- 能够仅支持Stage1或Stage2，或者同时支持Stage1和Stage2

- 支持最大16-bit的 ASIDs（Adress Space ID）.

- 支持最大16-bit的VMIDs （Virtual Machine IDs）.

- Address translation and protection according to Armv8.1 [4] Virtual Memory System Architecture

  SMMU translation tables shareable with PEs, allowing software the choice of sharing an existing table or creating an SMMU-private table. 

  49 bit VA, matching Armv8-A’s 2×48-bit translation table input sizes.

可选的实现:

-  Either stage 1 or stage 2.
-  Stage 1 and 2 support for the AArch32 (LPAE) and AArch64 translation table format.
-  Secure stream support.
-  Broadcast TLB invalidation.











## Reference LIsts



[ [1] Virtualization is Coming to a platform Near You](https://www.arm.com/files/pdf/System-MMU-Whitepaper-v8.0.pdf?_ga=2.33836321.1648683870.1529845594-1976022428.1529845594)



































































