# ELF(Executable and Linkable Format)

## 简介

### ELF

ELF（Executable and Linking Format）可执行和链接格式，由UNIX系统实验室发布，作为应用程序二进制接口（Application Binary Interface）的一部分。工具接口标准（Tool Interface Standards，TIS）委员会把ELF标准作为一种可移植的目标文件格式

目的:ELF标准是为软件开发人员提供一组二进制接口定义,这些接口可以延伸到所中操作系统,从而减少重新编码\重新编译程序的需要。接口的内容包括目标模块格式，可执行文件格式以及调试记录格式。



### System V ABI

为已编译好的应用程序定义了系统接口，目的是为应用程序提供一个标准的二进制接口，使得这些程序能够运行在符合System V Interface Defination和X/O喷Commen Application Environment Specification的操作系统之上。ABI包括两个部分：（1）通用部分：描述System V在所有硬件平台都一致的接口;（2）处理器相关部分：描述特定与某个处理器体系结构的实现。







### 目标文件

目标文件全部是程序的我二进制表示，目的是直接在某种处理器上执行。	

目标文件有3种类型：

1. 可重定位文件（Relocatable FIle   .o）：

   包含适用于与其他目标文件链接“**来创建可执行文件或者共享目标文件**”的代码和数据

2. 可执行文件（Executable FIle  .exe）：

   包含**适用于执行的一个程序**，此文件规定了exec（）如何创建一个程序的进程映像

3. 共享目标文件（Shared Object File  .so）

   包含可**在两种上下文中“链接”的代码和数据**。（1）链接器可以把该文件与其他可重定位文件一起处理，生成另外一个目标文件（2）动态连接器可以把该文件和某个可执行文件一起处理，来创建进程映像。





### 目标文件的格式

目标文件既要参与程序链接，又要参与程序执行。

| 链接视图                                   | 执行试图                           |
| ------------------------------------------ | ---------------------------------- |
| ELF头部（ELF Header）                      | ELF头部（ELF Header）              |
| 程序头部表（可选）（Program Header Table） | 程序头部表（Program Header Table） |
| 节区1                                      | 段1                                |
| ...                                        |                                    |
| 节区n                                      | 段2                                |
| ...                                        |                                    |
| ...                                        |                                    |
| 节区头部表（Section Header Table）         | 节区头部表（可选）                 |

#### ELF头部（ELF Header）

：用于描述整个文件的组织。

ELF文件的开始几个字节给出如何解释文件的提示信息，这些信息独立与处理器，也独立与文件的其余内容。

```
#define EI_NIDENT 16
typedef struct{
   typedef struct elf32_hdr {
          unsigned char e_ident[EI_NIDENT];	//其中包含Magic Number，指明是一个ELF文件，
          Elf32_Half e_type;	//目标文件的类型：0（未知类型），1（Relocatable）,2（Executable）,3（Shared Object）,4（Core file转储文件）
          Elf32_Half e_machine;	//文件的目标体系结构类型
          Elf32_Word e_version;	
          Elf32_Addr e_entry;>/* Entry point *///程序入口的虚拟地址
          Elf32_Off e_phoff;	//程序头部表的偏移
          Elf32_Off e_shoff;	//程序节区表的偏移
          Elf32_Word e_flags;	
          Elf32_Half e_ehsize;	//ELF头部大小
          Elf32_Half e_phentsize;	//程序头部表的表项大小
          Elf32_Half e_phnum;		//程序头部表的表项数目
          Elf32_Half e_shentsize;
          Elf32_Half e_shnum;	
          Elf32_Half e_shstrndx;	
  } Elf32_Ehdr;

    
}Elf32_Ehdr;
```



#### 程序头部表（Program Header Table）

程序的加载和动态链接

**程序头部**：描述与程序执行直接相关的目标文件结构信息，用来在文件中定位各个段的映像。

**程序加载**：给定一个目标文件，系统加载该文件到内存，启动程序执行

​		   

**动态链接**：系统加载了程序以后，必须通过解析构成进程的目标文件之间的符号引用，以便完整的构造进程映像



**告诉系统如何创建进程映像**，用于构造进程映像的目标文件必须具有程序头部表，可重定位文件不需要。

```
typedef struct elf32_phdr {
     Elf32_Word p_type;	//数组元素描述段的类型
     Elf32_Off p_offset; //从文件头到该段地一个字节的偏移
     Elf32_Addr p_vaddr;
  	 Elf32_Addr p_paddr;
 	 Elf32_Word p_filesz;
     Elf32_Word p_memsz;
	 Elf32_Word p_flags;
 	 Elf32_Word p_align;
 } Elf32_Phdr;
```







#### 节区部分

**包含链接视图的大量信息**：指令、数据、符号表、重定位信息...

包含目标文件所需的所有其他信息

（1）目标文件中的每个节区都有对应的节区头部表表项描述，反之不然

（2）每个节区占用文件中一个连续的字节区域

（3）文件中的节区不能重叠，不允许一个字节存在与两个节区

（4）目标文件可能包含非活动空间，这些区域不属于任何头部或者节区



##### 节区头部表（Section Header Table）

包含了描述文件节区的信息，每个节区在表中都有一项，每一项给出节区名称、节区大小等信息，<u>用于链接的目标文件必须包含节区头部表</u>



节区的具体位置和长度由e_shoff、e_shnum、e_shentsize确定

```
 节区头部数据结构
 
 typedef struct elf32_shdr {
   Elf32_Word        sh_name;	//节区名称
   Elf32_Word        sh_type;	
   Elf32_Word        sh_flags;
   Elf32_Addr        sh_addr;	//
   Elf32_Off         sh_offset;
   Elf32_Word        sh_size;
   Elf32_Word        sh_link;	//给出节区头部表索引链接
   Elf32_Word        sh_info;
   Elf32_Word        sh_addralign;
   Elf32_Word        sh_entsize;
 } Elf32_Shdr;

```



##### 特殊节区

下表列出一些常见的特殊节区

| 名称     | 类型         | 属性                    | 含义                                                         |
| -------- | ------------ | ----------------------- | ------------------------------------------------------------ |
| .bss     |              |                         | 包含未初始化数据                                             |
| .comment |              |                         | 包含版本控制信息                                             |
| .text    |              |                         | 包含程序的可执行指令                                         |
| .rodata  |              |                         | 包含制度信息                                                 |
| .data    |              |                         | 包含初始化了的数据，将出现程序的内存映像中                   |
| .debug   |              |                         |                                                              |
| .symtab  | SHT_SYMBOL   |                         | 包含一个“符号表“                                             |
| .dynamic |              |                         | 包含动态链接信息                                             |
| .plt     |              |                         | 包含”过程链接表“                                             |
| .fini    |              |                         |                                                              |
| .strtab  |              |                         | 包含字符串                                                   |
| .init    | SHT_PROGBITS | SHF_ALLOC+SHF_EXECINSTR | 包含可执行指令，是进程初始化代码的一部分，在程序开始执行之前执行这些代码 |

以.开头的节区名称是系统保留的

（1）字符串表

（2）符号表

包含用来定位、重定位程序中符号定义和引用的信息。符号表是对此数组的索引。























### ELF文件用到的数据类型

```
/* 32-bit ELF base types. */
   typedef unsigned int Elf32_Addr;
   typedef unsigned short Elf32_Half;
   typedef unsigned int Elf32_Off;
   typedef signed int Elf32_Sword;
   typedef unsigned int Elf32_Word;
  
  /* 64-bit ELF base types. */
  typedef unsigned long long Elf64_Addr;
  typedef unsigned short Elf64_Half;
  typedef signed short Elf64_SHalf;
  typedef unsigned long long Elf64_Off;
  typedef signed int Elf64_Sword;
  typedef unsigned int Elf64_Word;
  typedef unsigned long long Elf64_Xword;
  typedef signed long long Elf64_Sxword;
```

​                  

## 示例







## 目标文件格式分析工具



- ar

  用于创建、修改lib，也可以从lib中提取出单独的模块

- nm

  列出目标文件的符号清单

- objdump

- objcopy

- readelf

  显示elf文件信息

- strip

  去掉ELF文件的调试信息





#### 预处理器

```
gcc -E test.c -o test.i

作用：读取c程序，对伪指令和特殊符号进行处理，包括宏、条件编译、头文件、注释
```

#### 编译器

```
gcc -S test.i -o test.s

作用：生成汇编文件
```

#### 汇编器

```
gcc -c test.s -o test.o

作用：生成目标机器的指令文件（可以使用objdump查看）。把汇编语言代码翻译成目标机器指令。
```

#### 链接器

```
gcc -g test.o -o test

作用：生成可执行文件（可以使用objdump查看）

静态链接：
	主要工作是（1）重定位：确定每个符号在内存的绝对地址
			（2）符号解析：将所有目标文件链接在一起，解决各目标文件之间的符号交叉引用问题
动态链接：
```



#### 库

```
（1）静态库：

ar rcs libxxx.a xx1.o xx2.o

作用：生成静态哭libxxx.a
	 静态库是在“链接过程中将相关代码提取出来加入可执行文件的库”，ar只是将一些别的文件集合到一个文件中，然后打包，淡然也可以解包。
	 
（2）动态库：

gcc test.o -shared test.so

作用：生成动态链接库
	 动态链接库“在链接是只是创建一些符号表，而在运行时才将相关的库代码装入内存，映射到运行时相应进程的虚拟地址空间”
```





## References List                                                          

https://blog.csdn.net/xuehuafeiwu123/article/details/72963229

[ [2]ELF 文件格式分析-北京大学信息科学技术学院操作系统实验室 ](https://download.csdn.net/download/fengbohello/10481083)