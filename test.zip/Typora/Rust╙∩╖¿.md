# Rust

## 简介

Rust是一个系统编程语言，注重3个方面：安全、性能、并发性。为了实现这些目标没有采用垃圾回收机制（GC）。

### 一些关键字

安全：保证内存安全<-----------Mutation和Aliase不同时出现（采用borrow和ownership机制）

高性能：

并发性：消除一切数据竞争

零开销抽象（zero-cost abstractions）:

rust中零开销抽象的典型例子是“ownership”，抽象是在编译时完成的，不会在运行时为这些抽象付出任何代价。

基于trait的泛型

极小运行时

类型推断



### 环境搭建

#### Windows

1.下载运行：rustup-init.exe（https://www.rust-lang.org/zh-CN/install.html）

2.在 Rust 开发环境中，所有工具都安装到 `%USERPROFILE%\.cargo\bin` 目录， 并且您能够在这里找到 Rust 工具链，包括`rustc`、`cargo` 及 `rustup`。因此，Rust 开发者们通常会将此目录放入PATH环境变量

3安装Microsoft Visual C++ Build Tools 2017





## Cargo

Cargo是Rust的构建系统和包管理工具，Cargo主要完成：

1.构建代码

2.下载代码依赖的库编译这些库



### 用Cargo来管理项目



#### 1.快速创建新的Cargo项目

​	cargo new hello_world --bin

能够得到一个Cargo构建的rust项目骨架

#### 2.将已有rust项目用Cargo管理

2.1.将源文件放到正确位置（源文件一般放在src目录）

2.2.删除旧的可执行文件

2.3.创建一个Cargo配置文件（在项目主目录下创建Cargo.toml）

​	[package]	//表明下面的语句来配置一个包

​	name = "Hello_World"		//下面3行指定包的名字、版本、作者

​	version = "0.0.1"

​	authors = [ "name <xxx@example.com>" ]

​	[dependences]

2.4.构建并运行Cargo项目

​	cargo build

​	./target/debug/Hello_World

或者直接使用cargo run来构建并运行项目

#### 3.发布构建

​	cargo build -release

能够优化项目，使发布之后的项目能够运行的更快





## 语法和语义

#### 表达式VS语句

Rust是一个基于表达式的语言，只有两种语句，其他一切都是表达式。

两种语句：

​	声明语句：

​	表达式语句：

表达式返回一个值，而语句不返回

#### 变量绑定

let x:i32 = 5

1. x被绑定为int32类型，它的值是5
2. ：i32叫做“类型注解（type annotation）”可以省略，Rust有自己的类型推断系统
3. 这创建了一个不可变绑定（Rust为了安全性，默认创建不可变绑定），如果要创建一个可变绑定可以使用let mut x = 5 ;
4. x叫做一个模式，可以let (x,y)=(1,2);创建两个变量绑定
5. 作用域和隐藏
   1. 变量绑定的作用域是“块”，也就是一个{}

#### 函数

`fn add_one(x:i32)-> i32 {`

​	x+1

`}`



1.函数的参数必须指明类型，注意x+1后边没有分号，这是一个表达式，而不是一个语句。表达式返回一个值，语句不返回

2.提早返回

​	`fn add_one(x:i32)-> i32 {`

​		return x+1;	//此处函数就返回了，下边的x+1不会执行

​		x+1

​	`}`

3.发散函数

​	fn diverse()-> ! {

​		panic!("This function never returns") ;

​	}

​	发散函数无返回值，它的返回类型是！，发散函数可以被用作任何类型

​	let x:i32 = dirverse();

​	let y:String = diverse();

4.函数指针

​	let f : fn(i32)->i32



#### 原生类型

1.bool：布尔型（Rust中bool型占4个字节）

2.数字类型：分类+大小 组成

​	i8	i16	i32	i64

​	u8	816	u32	u64

​	isize

​	usize

​	f32	f64

其中i，u，f表示分类（有符号整型，无符号整型，浮点型）

size表示可变大小类型

##### 3.数组

​	let a = [1,2,3]

​	数组默认是不可变的，数组的类型是[T；N]，其中T是泛型类型，表示数组中数据类型，N是数组长度

​	let a = [0;20]	//将数组元素初始化为0

##### 4.vector

vector是一个动态数组，vector总在堆上分配内存，可以使用vec!宏来创建一个vector

let v = vec![1,2,3,4,5];

let v = vec![0;10];	//ten zeros

vector的类型是Vec<T>



访问vec元素，必须使用usize类型的下标：v[0],v[1]...

可以用for循环来迭代vector元素

for i in &v {

}

或者

for i in &mut v {

}

##### 4.切片（slice）

一个切片是一个数组的引用（或者“视图”），有利于安全，有效地访问数组的一部分，而不是拷贝

let a = [0,1,2,3,4] ;

let complete = &a[..] ;

let middle = &a[1..4] ;   //middle is [1,2,3]

切片的类型是&[T]

##### 5.元组

固定大小的有序列表，列表中的元素可以是“异质”的

let x = (1,"Hello")	或者 let x:(i32,&str) =  (1,"Hello")



元组索引

x.0  访问元组第一个元素

#### 分支/循环

let x = 5;

if x==5 {

​	println!();	

}else{

​	println!();

}

实例2：

let x = 5 ;

let y = if x==5 {10}else{20};



循环主要有3种：loop、while、for

实例3：

无限循环直到一些终止条件到达：loop

loop{

​	println!();

}

实例4：

while事先不知道要循环多少次

let mut done = false;

while !done{

​	

}

实例5：

事先知道要循环多少次

for x in 0..10{

}

Enumerate方法：

实例6:

for (index,value) in (5..10).enumerate() {

​	println!("{},{}",index,value)

}

循环标签（Loop Labels）

实例7：

'outer: for x in 0..10{

​	'inner: for y in 0..10{

​		

​	}

}



#### 所有权：Ownership

是rust保证内存安全的重要手段。



##### ownership

Rust中的变量绑定有一个属性：变量绑定拥有所绑定的值的所有权（ownership）。

##### 移动语义（Move senmantics）

let v = vec![1,2,3,4,5] ;		//v在栈上分配，[1,2,3,4,5]在堆上分配

let v2 = v ;

println!("vec[0] is :{}",vec[0]); 	//出错，[1,2,3,4,5]的所有权已经转移给了v2,利用v已经访问不到



##### copy trait

所有基本数据类型都实现了copy trait

trait可以理解为 为一个特定类型增加额外行为的标记

实现了copy trait的类型不遵循“所有权移动”规则。

let v = 5 ;

let v2 = v ;

println!("v:",v);	//是正确的，因为基本数据类型实现了copy trait，导致let v2 = v 不会出现ownership的move





#### 引用和借用：borrow



借用所有权，而不是拥有一个资源，一个借用变量绑定在它离开作用域时并不释放资源。

&T：引用是不可变的

&nut T：引用是可变的



##### borrow规则

1. 任何借用必须位于比拥有者更小的作用域（生命周期）

   let y:&i32;

   let x = 5 ;

   y = &x;

   println!("{}",y)

   是错误的，因为y的声明早于x。也就是说y的作用域或者生命周期大于x，而y借用了x，违反了任何借用必须位于比拥有者更小的作用域规则。

   

2. 对同一个资源的借用，一下情况不能同时出现在同一个作用域下：

   1. 一个或多个不可变引用（&T）

   2. 唯一一个可变引用（&mut T）

      即在同一个作用域下不能同时出现可变引用和不可变引用，要么只有唯一一个可变引用（只允许一个写），要么有一个或者多个不可变引用（允许多个读）

##### 借用能够避免的问题

1. 迭代器失效
2. 释放后使用



#### 生命周期



语法：

‘a   生命周期a

生命周期注解是“描述性的（_descriptive）”而不是“规则性的（_prescriptive_）”。这意味着生命周期是由代码决定的，并不是由生命周期注解决定的。



结构体struct的生命周期

impl块的生命周期





’static 生命周期：代表某个东西具有横跨整个程序的生命周期。



生命周期省略：？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？







#### 可变性



let mut x = 5 ;

let y = &mut x;

y是一个（指向）可变引用的不可变绑定，不可以将y与其他变量绑定（y = &mut z），但是可以利用y把x绑定到其他的值上（*y = 6）



##### 内部可变性VS外部可变性





##### 字段级别的可变性：

结构体的可变性位于它的绑定上（**<u>*可变性是绑定的一个属性*</u>**）不能够让结构体中的一些变量可变，另一些变量不可变，但是可以使用Cell<T>来模拟字段级别的可变性

struct Point{

​	x:i32,

​	y:Cell<i32>,

}

let point = Point{x:5, y:Cell::new<6>};

point.y.set(7);

println!("y:{:?}",point.y);



#### 结构体

struct Point{

​	x:i32,

​	y:i32,

}

let origin = Point{x:0,y:0};

println!("the origin is at ({},{})",origin.x,origin.y);



让你的变量可变一个可控的时间

let mut point = Point{};	//可变

point.x = 10;

let point = point ;		//不可变



##### 元组的结构体

struct color(i32,i32,i32);

struct point(i32,i32,i32);



##### 类单元结构体

结构体中没有任何成员

struct Elctron{}

struct Proton;





#### 枚举

代表多个可能变量的 类型。enum中的每个变量都可选是否关联数据

enum Message {

​	Quit,

​	ChangeColor(i32,i32,i32),

​	Move(x:i32,y:i32)

}



let x:Message = Message::Move{x:1,y:2};





#### 匹配：Match

匹配多重模式、范围匹配、守卫、混合与匹配，绑定

let x = 5 ;

let y = true;

Match x{

​	1 |2  if y => println!("one"),	//匹配多重模式,并且使用守卫，y将适用

​	3...6 => println!("three to six"),	//范围匹配	

​	7 => println!("two"),

​	e @ 8...10 => println!(“got a range element”), //绑定，把一个值绑定到e上，在匹配复杂数据类型是这个特性比较有用

​	_ => println!("else"),	//Match强制穷尽性检查，此行必须要有，用于检查剩余的i32类型，但是如果前边的匹配已经包含了x具有的所有值，则不能加此行代码

}

或者用在变量绑定的场合

let number = match x{

​	1 => "one",

​	...

}

##### 匹配枚举

enum Message{

​	Quit,

​	ChangeColor(i32,i32,i32)

​	Move(x:i32,y:i32),

​	Value(i32)

}

fn quit(){}

fn change_color(){}

fn move(){}



Match msg {

​	Message::Quit => quit(),

​	Message::ChangeColor => change_color(),

​	Message::Move => move(0,),

​	Message::value(i) if i < 5 => println!(""),	//Match中的守卫

}



#### 方法语法

##### 方法调用：用impl实现带self的函数

struct Circle {

​	x:f64,

​	y:f64

​	radius:f64,

}

impl Circle{

​	fn area(&self)->f64 {	//&self 或者 self 或者&mut self

​		str::f64::consts::PI*(self.radius*self.radius)

​	}

​	fn .........

}



let c = Circle{x:0.0, y:0.0 , radius:2.0};

println!("{}",c.area());

##### 链式方法调用

let c = Circle{x:0.0, y:0.0 , radius:2.0};

c.grow(2.0).area();



##### 关联函数:不带self

struct Circle {

​	x:f64,

​	y:f64

​	radius:f64,

}

impl Circle{

​	fn new(x:f64, y:f64, radius:f64)->Circle {	//&self 或者 self 或者&mut self

​		Circle {

​			x:x,

​			y:y

​			radius:radius,

​		}

​	}

}

let c = Circle::new(0.0, 0.0 ,2.0); //关联函数用：：调用

##### 创建者模式

Rust中没有方法重载，命名参数和可变参数，而是用创建者模式来代替







#### 字符串

Rust有两种主要的字符串类型：

​	&str：字符串片段

​	String：在堆上分配的字符串，通常是一个字符串片段通过to_string得到

Rust中的字符串是一串UTF-8字节编码的序列，不以null结尾，并且可以包含null字节

Rust字符串常量是&‘static str类型



let mut s = "Hello".to_string();

s.push_str(,World.);

String能通过&强制转换为&str



##### 索引

let hachiko = "忠犬八公"

let dog = hackiko.chars().nth(1) ;

println!("{:?}",dog);



for c in hackiko.chars(){}

for c in hackiko.chars(){}

##### 切片

let dog = "hackiko"

let hacki = &dog[0...5]	//下标示字节的偏移，而不是字符的便宜

##### 拼接

**String和&str**

let hello = "Hello".to_string();

let world = "world!"

let hello_world = hello + world;



**String和String**

let hello = "Hello".to_string();

let world = "World!".to_string();

let hello_world = hello + &world;



#### 泛型：参数多态

Rust提供了一个泛型的类型Option<T>

enum Option<T> {

​	Some(T),

​	None,

}



let x : Option<i32> = Some(5);





泛型函数

fn takes_anything<T,U>(x:T , y:U){}



泛型结构体

struct point<T> {

​	x:T ,

​	y:T,

}

impl<T> point<T>{

​	fn swap(&mut self){

​		std::mem::swap(&mut self.x , &mut self.y) ;

​	}

}



#### Traits

Traits告诉编译器一个类型必须提供哪些功能的语言特性。traits很有用是因为他们允许一个类型对他的行为提供特定的承诺，泛型函数可以显示的限制（bound）他所接受的类型

Struct Circle {

​	x: f64,

​	y:f64,

​	radius:f64,

}

traits HasArea {		//定义一个traits，在里面只声明函数标记

​	fn area(&self)->f64;

}

impl HasArea for Circle {	//使用impl traits for item语法

​	fn area(&self)->f64 {

​		std::f64::conts::PI*sile.radius*self.radius

​	}

}

##### 泛型函数的traits bound

fn print_area<T: HashArea>(shape:T) {	//此行使用了traits bound，限制了泛型T必须实现了traits HashArea

​	println!("the shape has an area of {}",shape.area());

}

##### 泛型结构体的traits bound

struct  Retangle<T>{x:T, y:T, width:T, height:T,}

impl<T: PartiaEq> Retangle<T> {

​	fn is_square(&self) -> bool {

​		self.width == self.height

​	}

}

##### 实现traits的规则





##### 多traits bound限制

fn foo<T: Clone + Debug>(x:T) {		//使用+符号用多个traits限定定义的类型

}

或者使用where从句为一个类型添加traits bound

fn foo<T,K>(x:T, y:K) 

​	where T:Clone,

​		     K :Clone+Debug {

} 



##### Drop

drop是Rust标准库提供的特殊traits，drop traits提供了当一个值离开其作用域时运行一些代码的方法，常用来做清理工作

struct HasDrop;

impl Drop for HasDrop {

​	fn drop(&mut self){

​		println!("Droping");

​	}

}



#### if let和while let

let option = Some(5) ;

fn foo().....

fn bar().....

if let Some(x) = option {

​	foo(x) ;

}else{

​	bar(x);

}

一直循环，直到匹配到特定模式

let mut v = vec![12,3,4,5,6];

while let Some(x) = v.pop() {

​	println!("{}",x);

}





#### （？？？？？？？？？？）taints对象



#### 宏

宏允许我们在句法水平上进行抽象，宏展开在任何静态检查之前。







